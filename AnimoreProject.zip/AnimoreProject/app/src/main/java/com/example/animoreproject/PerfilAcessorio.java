package com.example.animoreproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PerfilAcessorio extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil_acessorio);
    }
}