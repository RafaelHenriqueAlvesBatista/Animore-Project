package com.example.animoreproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.GravityCompat;
import androidx.core.widget.NestedScrollView;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.squareup.picasso.Picasso;

public class FormCadastroAnimal extends AppCompatActivity {

    // VARIAVEIS DA ACTIVITY
    private int telaFormulario = 1;
    private int valorVacina = 1;
    private int[] fotosAnimal = new int[5];
    private int[] fotosAcessorio = new int[5];
    private int fotoAnimalSelecionada = -1;
    private int fotoAcessorioSelecionada = -1;
    private boolean modoAdicionar = false;

    // REALIZA A VERIFICACAO DA IMAGEM ESCOLHIDA NO DISPOSITIVO, AO INVES DE COLOCAR UM NUMERO MAGICO
    private static final int PICK_IMAGE_REQUEST = 1;

    // REALIZA A ESCOLHA DOS FORMULARIOS
    private TextView txvTituloAnimal, txvTituloAcessorio;

    // COMPONENTES DO FORMULARIO DO ANIMAL
    private LinearLayout llyFormularioAnimal;
    private Spinner spnTipoAnimal, spnRacaAnimal, spnVacinaAnimal;
    private TextInputEditText edtNomeAnimal, edtIdadeAnimal, edtPesoAnimal;
    private EditText edtDescricaoAnimal;
    private ImageView imvFotoAnimal1, imvFotoAnimal2, imvFotoAnimal3, imvFotoAnimal4, imvFotoAnimal5;
    private Button btnAdicionarFotoAnimal, btnRegistrarAnimal;
    private RadioGroup rdgSexoAnimal;
    private RadioButton rdbSexoAnimalMacho, rdbSexoAnimalFemea, rdbSexoAnimalDesconhecido;

    // COMPONENTES DO FORMULARIO DO ACESSORIO
    private LinearLayout llyFormularioAcessorio;
    private Spinner spnTipoAcessorio;
    private TextInputEditText edtNomeAcessorio;
    private EditText edtDescricaoAcessorio;
    private NestedScrollView scvDescricaoAcessorio;
    private ImageView imvFotoAcessorio1, imvFotoAcessorio2, imvFotoAcessorio3, imvFotoAcessorio4, imvFotoAcessorio5;
    private Button btnAdicionarFotoAcessorio, btnRegistrarAcessorio;

    // COMPONENTES DAS FOTOS
    private ConstraintLayout clyFoto;
    private TextView txvTituloFotoAnimal;
    private ImageView imvFotoBig;
    private Button btnSairFoto, btnImportarFoto;

    // COMPONENTE DAS TELAS
    private DrawerLayout drlPagina;
    private View headerView;
    private CustomScrollView scvTela;
    private ConstraintLayout clyTelaCarregando;
    private FloatingActionButton fabVoltar;

    // COMPONENTES TOOLBAR
    private ImageButton botaoMenu, botaoCompartilhar;

    // COMPONENTES MENU
    private NavigationView nvvMenu;
    private TextView txvMenuNomeUsuario;
    private ImageView imvMenuFotoUsuario;
    private Menu menu;
    private MenuItem mnuInicial;
    private MenuItem mnuPerfil;
    private MenuItem mnuAnimais;
    private MenuItem mnuMensagens;
    private MenuItem mnuOpcoes;
    private MenuItem mnuSair;

    // VARIAVEIS DO FIREBASE
    private Uri uriFoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_animal);
        instanciarComponentes();
        programarComponentes();
    }

    private void instanciarComponentes() {
        botaoMenu             = findViewById(R.id.botaoMenu);
        botaoCompartilhar     = findViewById(R.id.botaoCompartilhar);

        drlPagina             = findViewById(R.id.drlPagina);

        nvvMenu               = findViewById(R.id.nvvMenu);
        headerView            = nvvMenu.getHeaderView(0);

        txvMenuNomeUsuario    = headerView.findViewById(R.id.txvMenuNomeUsuario);
        imvMenuFotoUsuario    = headerView.findViewById(R.id.imvMenuFotoUsuario);
        menu                  = nvvMenu.getMenu();
        mnuInicial            = menu.findItem(R.id.menu_paginaInicial);
        mnuPerfil             = menu.findItem(R.id.menu_perfil);
        mnuAnimais            = menu.findItem(R.id.menu_meusAnimais);
        mnuMensagens          = menu.findItem(R.id.menu_mensagens);
        mnuOpcoes             = menu.findItem(R.id.menu_opcoes);
        mnuSair               = menu.findItem(R.id.menu_sair);

        scvTela                   = findViewById(R.id.scvTela);

        fabVoltar                 = findViewById(R.id.fabVoltar);

        txvTituloAnimal           = findViewById(R.id.txvTituloAnimal);
        txvTituloAcessorio        = findViewById(R.id.txvTituloAcessorio);

        llyFormularioAnimal       = findViewById(R.id.llyFormularioAnimal);

        spnTipoAnimal             = findViewById(R.id.spnTipoAnimal);
        spnRacaAnimal             = findViewById(R.id.spnRacaAnimal);
        edtNomeAnimal             = findViewById(R.id.edtNomeAnimal);
        edtIdadeAnimal            = findViewById(R.id.edtIdadeAnimal);
        edtPesoAnimal             = findViewById(R.id.edtPesoAnimal);
        spnVacinaAnimal           = findViewById(R.id.spnVacinaAnimal);
        rdgSexoAnimal             = findViewById(R.id.rdgSexoAnimal);
        rdbSexoAnimalMacho        = findViewById(R.id.rdbSexoAnimalMacho);
        rdbSexoAnimalFemea        = findViewById(R.id.rdbSexoAnimalFemea);
        rdbSexoAnimalDesconhecido = findViewById(R.id.rdbSexoAnimalDesconhecido);
        edtDescricaoAnimal        = findViewById(R.id.edtDescricaoAnimal);

        btnAdicionarFotoAnimal    = findViewById(R.id.btnAdicionarFotoAnimal);
        imvFotoAnimal1            = findViewById(R.id.imvFotoAnimal1);
        imvFotoAnimal2            = findViewById(R.id.imvFotoAnimal2);
        imvFotoAnimal3            = findViewById(R.id.imvFotoAnimal3);
        imvFotoAnimal4            = findViewById(R.id.imvFotoAnimal4);
        imvFotoAnimal5            = findViewById(R.id.imvFotoAnimal5);

        btnRegistrarAnimal        = findViewById(R.id.btnRegistrarAnimal);

        llyFormularioAcessorio    = findViewById(R.id.llyFormularioAcessorio);

        spnTipoAcessorio          = findViewById(R.id.spnTipoAcessorio);
        edtNomeAcessorio          = findViewById(R.id.edtNomeAcessorio);
        edtDescricaoAcessorio     = findViewById(R.id.edtDescricaoAcessorio);
        scvDescricaoAcessorio     = findViewById(R.id.scvDescricaoAcessorio);

        btnAdicionarFotoAcessorio = findViewById(R.id.btnAdicionarFotoAcessorio);
        imvFotoAcessorio1         = findViewById(R.id.imvFotoAcessorio1);
        imvFotoAcessorio2         = findViewById(R.id.imvFotoAcessorio2);
        imvFotoAcessorio3         = findViewById(R.id.imvFotoAcessorio3);
        imvFotoAcessorio4         = findViewById(R.id.imvFotoAcessorio4);
        imvFotoAcessorio5         = findViewById(R.id.imvFotoAcessorio5);

        btnRegistrarAcessorio     = findViewById(R.id.btnRegistrarAcessorio);

        clyFoto                   = findViewById(R.id.clyFoto);
        txvTituloFotoAnimal       = findViewById(R.id.txvTituloFotoAnimal);
        imvFotoBig                = findViewById(R.id.imvFotoBig);
        btnSairFoto               = findViewById(R.id.btnSairFoto);
        btnImportarFoto           = findViewById(R.id.btnImportarFoto);

        clyTelaCarregando         = findViewById(R.id.clyTelaCarregando);

        rdbSexoAnimalMacho.setChecked(true);

        setAdapterVacinaAnimal(valorVacina);
    }

    private void programarComponentes() {
        botaoMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drlPagina.openDrawer(GravityCompat.START);
            }
        });

        mnuInicial.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Intent telaInicial = new Intent(FormCadastroAnimal.this, TelaInicial.class);
                startActivity(telaInicial);
                return true;
            }
        });

        mnuPerfil.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Intent perfilUsuario = new Intent(FormCadastroAnimal.this, PerfilUsuario.class);
                startActivity(perfilUsuario);
                return true;
            }
        });

        mnuAnimais.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Intent perfilUsuario = new Intent(FormCadastroAnimal.this, ListaMeusAnimais.class);
                startActivity(perfilUsuario);
                return true;
            }
        });

        mnuMensagens.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Toast.makeText(FormCadastroAnimal.this, "Funcionalidade ainda não implementada!", Toast.LENGTH_SHORT).show();
                return true;
            }
        });

        mnuOpcoes.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Toast.makeText(FormCadastroAnimal.this, "Funcionalidade ainda não implementada!", Toast.LENGTH_SHORT).show();
                return true;
            }
        });

        mnuSair.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                AlertDialog.Builder builder = new AlertDialog.Builder(FormCadastroAnimal.this);
                builder.setMessage("Deseja realmente encerrar a sessão?")
                        .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                drlPagina.closeDrawer(GravityCompat.START);
                                FirebaseAuth.getInstance().signOut();
                                Intent enviarFeedback = new Intent(FormCadastroAnimal.this, FormLogin.class);
                                enviarFeedback.putExtra("enviarFeedback", 3);
                                startActivity(enviarFeedback);
                                finish();
                            }
                        })
                        .setNegativeButton("Não", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {}
                        })
                        .create()
                        .show();
                return true;
            }
        });

        fabVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        txvTituloAnimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (telaFormulario != 1){
                    abrirFormularioAnimal();
                }
            }
        });

        txvTituloAcessorio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (telaFormulario == 1){
                    abrirFormularioAcessorio();
                }
            }
        });

        spnTipoAnimal.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                valorVacina = i;
                ArrayAdapter<String> adapterRaca;
                switch (i){
                    case 0:
                        adapterRaca = new ArrayAdapter<>(FormCadastroAnimal.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.animal_breedDog));
                        adapterRaca.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spnRacaAnimal.setAdapter(adapterRaca);
                        break;
                    case 1:
                        adapterRaca = new ArrayAdapter<>(FormCadastroAnimal.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.animal_breedCat));
                        adapterRaca.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spnRacaAnimal.setAdapter(adapterRaca);
                        break;
                    case 2:
                        adapterRaca = new ArrayAdapter<>(FormCadastroAnimal.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.animal_breedBird));
                        adapterRaca.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spnRacaAnimal.setAdapter(adapterRaca);
                        break;
                    case 3:
                        adapterRaca = new ArrayAdapter<>(FormCadastroAnimal.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.animal_breedRat));
                        adapterRaca.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spnRacaAnimal.setAdapter(adapterRaca);
                        break;
                    case 4:
                        adapterRaca = new ArrayAdapter<>(FormCadastroAnimal.this, android.R.layout.simple_spinner_item, getResources().getStringArray(R.array.animal_breedOther));
                        adapterRaca.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spnRacaAnimal.setAdapter(adapterRaca);
                        break;
                    default:
                        break;
                }
                setAdapterVacinaAnimal(valorVacina);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {}
        });

        edtDescricaoAnimal.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                scvTela.setScrollingEnabled(!hasFocus);
            }
        });

        llyFormularioAnimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtDescricaoAnimal.clearFocus();
            }
        });

        btnAdicionarFotoAnimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ativacaoBotoes(false);
                txvTituloFotoAnimal.setText(R.string.title_photoAnimal);
                clyFoto.setVisibility(View.VISIBLE);
                modoAdicionar = true;
                sobrescreverPrevia();
            }
        });

        btnSairFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ativacaoBotoes(true);
                clyFoto.setVisibility(View.GONE);
                modoAdicionar = false;
                imvFotoBig.setImageResource(R.color.text_300);
                imvFotoBig.setBackgroundColor(getResources().getColor(R.color.transparent));
            }
        });

        btnImportarFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(intent, PICK_IMAGE_REQUEST);
            }
        });

        imvFotoAnimal1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ativacaoBotoes(false);
                txvTituloFotoAnimal.setText(R.string.title_photoAnimal);
                clyFoto.setVisibility(View.VISIBLE);
                fotoAnimalSelecionada = 0;
                sobrescreverPrevia();
            }
        });
        imvFotoAnimal2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ativacaoBotoes(false);
                txvTituloFotoAnimal.setText(R.string.title_photoAnimal);
                clyFoto.setVisibility(View.VISIBLE);
                fotoAnimalSelecionada = 1;
                sobrescreverPrevia();
            }
        });
        imvFotoAnimal3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ativacaoBotoes(false);
                txvTituloFotoAnimal.setText(R.string.title_photoAnimal);
                clyFoto.setVisibility(View.VISIBLE);
                fotoAnimalSelecionada = 2;
                sobrescreverPrevia();
            }
        });
        imvFotoAnimal4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ativacaoBotoes(false);
                txvTituloFotoAnimal.setText(R.string.title_photoAnimal);
                clyFoto.setVisibility(View.VISIBLE);
                fotoAnimalSelecionada = 3;
                sobrescreverPrevia();
            }
        });
        imvFotoAnimal5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ativacaoBotoes(false);
                txvTituloFotoAnimal.setText(R.string.title_photoAnimal);
                clyFoto.setVisibility(View.VISIBLE);
                fotoAnimalSelecionada = 4;
                sobrescreverPrevia();
            }
        });

        edtDescricaoAcessorio.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                scvTela.setScrollingEnabled(!hasFocus);
            }
        });

        llyFormularioAcessorio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edtDescricaoAcessorio.clearFocus();
            }
        });

        btnAdicionarFotoAcessorio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ativacaoBotoes(false);
                txvTituloFotoAnimal.setText(R.string.title_photoAccesory);
                clyFoto.setVisibility(View.VISIBLE);
                modoAdicionar = true;
                sobrescreverPrevia();
            }
        });

        imvFotoAcessorio1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ativacaoBotoes(false);
                txvTituloFotoAnimal.setText(R.string.title_photoAccesory);
                clyFoto.setVisibility(View.VISIBLE);
                fotoAcessorioSelecionada = 0;
                sobrescreverPrevia();
            }
        });
        imvFotoAcessorio2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ativacaoBotoes(false);
                txvTituloFotoAnimal.setText(R.string.title_photoAccesory);
                clyFoto.setVisibility(View.VISIBLE);
                fotoAcessorioSelecionada = 1;
                sobrescreverPrevia();
            }
        });
        imvFotoAcessorio3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ativacaoBotoes(false);
                txvTituloFotoAnimal.setText(R.string.title_photoAccesory);
                clyFoto.setVisibility(View.VISIBLE);
                fotoAcessorioSelecionada = 2;
                sobrescreverPrevia();
            }
        });
        imvFotoAcessorio4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ativacaoBotoes(false);
                txvTituloFotoAnimal.setText(R.string.title_photoAccesory);
                clyFoto.setVisibility(View.VISIBLE);
                fotoAcessorioSelecionada = 3;
                sobrescreverPrevia();
            }
        });
        imvFotoAcessorio5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ativacaoBotoes(false);
                txvTituloFotoAnimal.setText(R.string.title_photoAccesory);
                clyFoto.setVisibility(View.VISIBLE);
                fotoAcessorioSelecionada = 4;
                sobrescreverPrevia();
            }
        });

        btnRegistrarAnimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                avisoRegistrar();
            }
        });

        btnRegistrarAcessorio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                avisoRegistrar();
            }
        });
    }

    private void abrirFormularioAnimal() {
        telaFormulario = 1;
        llyFormularioAnimal.setVisibility(View.VISIBLE);
        llyFormularioAcessorio.setVisibility(View.GONE);
        txvTituloAnimal.setBackgroundResource(R.drawable.layout_escolha_doacao_background_left);
        txvTituloAcessorio.setBackgroundResource(R.color.white);
        txvTituloAnimal.setTextColor(getResources().getColor(R.color.white));
        txvTituloAcessorio.setTextColor(getResources().getColor(R.color.text_700));
    }
    private void abrirFormularioAcessorio() {
        telaFormulario = 2;
        llyFormularioAnimal.setVisibility(View.GONE);
        llyFormularioAcessorio.setVisibility(View.VISIBLE);
        txvTituloAnimal.setBackgroundResource(R.color.white);
        txvTituloAcessorio.setBackgroundResource(R.drawable.layout_escolha_doacao_background_right);
        txvTituloAnimal.setTextColor(getResources().getColor(R.color.text_700));
        txvTituloAcessorio.setTextColor(getResources().getColor(R.color.white));
    }

    private void setAdapterVacinaAnimal(int item) {
        CustomSpinnerAdapter adapter;
        switch (item){
            case 0:
                adapter = new CustomSpinnerAdapter(FormCadastroAnimal.this, R.layout.checkbox_item, getResources().getStringArray(R.array.animal_vacinesDog));
                spnVacinaAnimal.setAdapter(adapter);
                break;
            case 1:
                adapter = new CustomSpinnerAdapter(FormCadastroAnimal.this, R.layout.checkbox_item, getResources().getStringArray(R.array.animal_vacinesCat));
                spnVacinaAnimal.setAdapter(adapter);
                break;
            case 2:
                adapter = new CustomSpinnerAdapter(FormCadastroAnimal.this, R.layout.checkbox_item, getResources().getStringArray(R.array.animal_vacinesBird));
                spnVacinaAnimal.setAdapter(adapter);
                break;
            case 3:
                adapter = new CustomSpinnerAdapter(FormCadastroAnimal.this, R.layout.checkbox_item, getResources().getStringArray(R.array.animal_vacinesRat));
                spnVacinaAnimal.setAdapter(adapter);
                break;
            case 4:
                adapter = new CustomSpinnerAdapter(FormCadastroAnimal.this, R.layout.checkbox_item, getResources().getStringArray(R.array.animal_vacinesOther));
                spnVacinaAnimal.setAdapter(adapter);
                break;
            default:
                break;
        }
    }

    private void ativacaoBotoes(boolean marca) {
        txvTituloAnimal.setEnabled(marca);
        txvTituloAcessorio.setEnabled(marca);

        spnTipoAnimal.setEnabled(marca);
        spnRacaAnimal.setEnabled(marca);
        edtNomeAnimal.setEnabled(marca);
        edtIdadeAnimal.setEnabled(marca);
        edtPesoAnimal.setEnabled(marca);
        spnVacinaAnimal.setEnabled(marca);
        rdgSexoAnimal.setEnabled(marca);
        rdbSexoAnimalMacho.setEnabled(marca);
        rdbSexoAnimalFemea.setEnabled(marca);
        rdbSexoAnimalDesconhecido.setEnabled(marca);
        edtDescricaoAnimal.setEnabled(marca);
        btnAdicionarFotoAnimal.setEnabled(marca);
        imvFotoAnimal1.setEnabled(marca);
        imvFotoAnimal2.setEnabled(marca);
        imvFotoAnimal3.setEnabled(marca);
        imvFotoAnimal4.setEnabled(marca);
        imvFotoAnimal5.setEnabled(marca);
        btnRegistrarAnimal.setEnabled(marca);

        spnTipoAcessorio.setEnabled(marca);
        edtNomeAcessorio.setEnabled(marca);
        edtDescricaoAcessorio.setEnabled(marca);
        btnAdicionarFotoAcessorio.setEnabled(marca);
        imvFotoAcessorio1.setEnabled(marca);
        imvFotoAcessorio2.setEnabled(marca);
        imvFotoAcessorio3.setEnabled(marca);
        imvFotoAcessorio4.setEnabled(marca);
        imvFotoAcessorio5.setEnabled(marca);
        btnRegistrarAcessorio.setEnabled(marca);

        if (marca) {
            scvTela.setOnTouchListener(null);
        } else {
            scvTela.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View view, MotionEvent motionEvent) {
                    return true;
                }
            });
        }
    }

    private int checarFotosVazias(){
        int fotoVazia = -1;
        if (telaFormulario == 1){
            for (int i = 0; i < fotosAnimal.length; i++) {
                if (fotosAnimal[i] == 0) {
                    fotoVazia = i;
                    break;
                } else if (i == 4) {
                    fotoVazia = 4;
                }
            }
        } else {
            for (int i = 0; i < fotosAcessorio.length; i++) {
                if (fotosAcessorio[i] == 0) {
                    fotoVazia = i;
                    break;
                } else if (i == 4) {
                    fotoVazia = 4;
                }
            }
        }
        return fotoVazia;
    }

    private void selecionarCampoFoto (int fotoVazia){
        if (telaFormulario == 1){
            switch (fotoVazia) {
                case 0:
                    Picasso.get().load(uriFoto).into(imvFotoAnimal1);
                    break;
                case 1:
                    Picasso.get().load(uriFoto).into(imvFotoAnimal2);
                    break;
                case 2:
                    Picasso.get().load(uriFoto).into(imvFotoAnimal3);
                    break;
                case 3:
                    Picasso.get().load(uriFoto).into(imvFotoAnimal4);
                    break;
                case 4:
                    Picasso.get().load(uriFoto).into(imvFotoAnimal5);
                    break;
                default:
                    System.out.println("ERRO AO SELECIONAR FOTO!");
                    break;
            }
            if (fotoVazia > -1 && fotoVazia < 5) {
                fotosAnimal[fotoVazia] = 1;
            }
        } else {
            switch (fotoVazia) {
                case 0:
                    Picasso.get().load(uriFoto).into(imvFotoAcessorio1);
                    break;
                case 1:
                    Picasso.get().load(uriFoto).into(imvFotoAcessorio2);
                    break;
                case 2:
                    Picasso.get().load(uriFoto).into(imvFotoAcessorio3);
                    break;
                case 3:
                    Picasso.get().load(uriFoto).into(imvFotoAcessorio4);
                    break;
                case 4:
                    Picasso.get().load(uriFoto).into(imvFotoAcessorio5);
                    break;
                default:
                    System.out.println("ERRO AO SELECIONAR FOTO!");
                    break;
            }
            if (fotoVazia > -1 && fotoVazia < 5) {
                fotosAcessorio[fotoVazia] = 1;
            }
        }
    }

    private void sobrescreverPrevia() {
        if (modoAdicionar) {
            imvFotoBig.setImageResource(R.color.text_300);
            imvFotoBig.setBackgroundColor(getResources().getColor(R.color.transparent));
        } else {
            if (telaFormulario == 1){
                switch (fotoAnimalSelecionada) {
                    case 0:
                        if (imvFotoAnimal1.getDrawable() != null) {
                            imvFotoBig.setImageResource(R.color.transparent);
                            imvFotoBig.setBackground(imvFotoAnimal1.getDrawable());
                        }
                        break;
                    case 1:
                        if (imvFotoAnimal2.getDrawable() != null) {
                            imvFotoBig.setImageResource(R.color.transparent);
                            imvFotoBig.setBackground(imvFotoAnimal2.getDrawable());
                        }
                        break;
                    case 2:
                        if (imvFotoAnimal3.getDrawable() != null) {
                            imvFotoBig.setImageResource(R.color.transparent);
                            imvFotoBig.setBackground(imvFotoAnimal3.getDrawable());
                        }
                        break;
                    case 3:
                        if (imvFotoAnimal4.getDrawable() != null) {
                            imvFotoBig.setImageResource(R.color.transparent);
                            imvFotoBig.setBackground(imvFotoAnimal4.getDrawable());
                        }
                        break;
                    case 4:
                        if (imvFotoAnimal5.getDrawable() != null) {
                            imvFotoBig.setImageResource(R.color.transparent);
                            imvFotoBig.setBackground(imvFotoAnimal5.getDrawable());
                        }
                        break;
                    default:
                        break;
                }
            } else {
                switch (fotoAcessorioSelecionada) {
                    case 0:
                        if (imvFotoAcessorio1.getDrawable() != null) {
                            imvFotoBig.setImageResource(R.color.transparent);
                            imvFotoBig.setBackground(imvFotoAcessorio1.getDrawable());
                        }
                        break;
                    case 1:
                        if (imvFotoAcessorio2.getDrawable() != null) {
                            imvFotoBig.setImageResource(R.color.transparent);
                            imvFotoBig.setBackground(imvFotoAcessorio2.getDrawable());
                        }
                        break;
                    case 2:
                        if (imvFotoAcessorio3.getDrawable() != null) {
                            imvFotoBig.setImageResource(R.color.transparent);
                            imvFotoBig.setBackground(imvFotoAcessorio3.getDrawable());
                        }
                        break;
                    case 3:
                        if (imvFotoAcessorio4.getDrawable() != null) {
                            imvFotoBig.setImageResource(R.color.transparent);
                            imvFotoBig.setBackground(imvFotoAcessorio4.getDrawable());
                        }
                        break;
                    case 4:
                        if (imvFotoAcessorio5.getDrawable() != null) {
                            imvFotoBig.setImageResource(R.color.transparent);
                            imvFotoBig.setBackground(imvFotoAcessorio5.getDrawable());
                        }
                        break;
                    default:
                        break;
                }
            }
        }
    }

    private void avisoRegistrar() {
        String mensagem;
        if (telaFormulario == 1){
            mensagem = "\nAo cadastrar o seu animal, o aplicativo vai disponibilizá-lo para qualquer um adotá-lo.\n";
        } else {
            mensagem = "\nAo cadastrar o acessório, o aplicativo vai disponibilizá-lo para qualquer um que deseje obtê-lo.\n";
        }
        mensagem += "Prosseguir com o cadastro?";
        AlertDialog.Builder builder = new AlertDialog.Builder(FormCadastroAnimal.this);
        builder.setIcon(R.drawable.ic_info);
        builder.setTitle("Informação");
        builder.setMessage(mensagem)
                .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //TODO
                    }
                })
                .setNegativeButton("Não", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {}
                })
                .create()
                .show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null) {
            uriFoto = data.getData();

            Picasso.get().load(uriFoto).into(imvFotoBig);

            if (modoAdicionar) {
                selecionarCampoFoto(checarFotosVazias());
            } else {
                if (telaFormulario == 1){
                    selecionarCampoFoto(fotoAnimalSelecionada);
                } else {
                    edtDescricaoAcessorio.clearFocus();
                    selecionarCampoFoto(fotoAcessorioSelecionada);
                }
            }
        }
    }

    @Override
    public void onBackPressed(){
        if (drlPagina.isDrawerOpen(GravityCompat.START)) {
            drlPagina.closeDrawer(GravityCompat.START);
        } else {
            finish();
        }
    }
}