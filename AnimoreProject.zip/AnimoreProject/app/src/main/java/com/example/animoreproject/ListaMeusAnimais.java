package com.example.animoreproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class ListaMeusAnimais extends AppCompatActivity {

    // COMPONENTES TOOLBAR
    private ImageButton botaoMenu, botaoCompartilhar;

    // COMPONENTES TELA
    private DrawerLayout drlPagina;
    private View headerView;
    private FloatingActionButton fabAdicionar;

    // COMPONENTES MENU
    private NavigationView nvvMenu;
    private TextView txvMenuNomeUsuario;
    private ImageView imvMenuFotoUsuario;
    private Menu menu;
    private MenuItem mnuInicial;
    private MenuItem mnuPerfil;
    private MenuItem mnuAnimais;
    private MenuItem mnuMensagens;
    private MenuItem mnuOpcoes;
    private MenuItem mnuSair;

    // COMPONENTES LISTA VAZIA
    private LinearLayout llyListaVazia;
    private Button btnCadastrarAnimal;

    // COMPONENTES LISTA ANIMAIS
    private CardView cdvMeuAnimal1, cdvMeuAnimal2, cdvMeuAnimal3, cdvMeuAnimal4, cdvMeuAnimal5, cdvMeuAnimal6, cdvMeuAnimal7, cdvMeuAnimal8, cdvMeuAnimal9, cdvMeuAnimal10;
    private ImageView imvMeuAnimal1, imvMeuAnimal2, imvMeuAnimal3, imvMeuAnimal4, imvMeuAnimal5, imvMeuAnimal6, imvMeuAnimal7, imvMeuAnimal8, imvMeuAnimal9, imvMeuAnimal10;
    private TextView txvNomeMeuAnimal1, txvNomeMeuAnimal2, txvNomeMeuAnimal3, txvNomeMeuAnimal4, txvNomeMeuAnimal5, txvNomeMeuAnimal6, txvNomeMeuAnimal7, txvNomeMeuAnimal8, txvNomeMeuAnimal9, txvNomeMeuAnimal10;
    private TextView txvIdadeMeuAnimal1, txvIdadeMeuAnimal2, txvIdadeMeuAnimal3, txvIdadeMeuAnimal4, txvIdadeMeuAnimal5, txvIdadeMeuAnimal6, txvIdadeMeuAnimal7, txvIdadeMeuAnimal8, txvIdadeMeuAnimal9, txvIdadeMeuAnimal10;
    private TextView txvRacaMeuAnimal1, txvRacaMeuAnimal2, txvRacaMeuAnimal3, txvRacaMeuAnimal4, txvRacaMeuAnimal5, txvRacaMeuAnimal6, txvRacaMeuAnimal7, txvRacaMeuAnimal8, txvRacaMeuAnimal9, txvRacaMeuAnimal10;

    // ATRIBUTOS DO FIREBASE
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    String usuarioID;
    private DatabaseReference databaseRef;
    private StorageReference storageRef;
    private DocumentReference documentReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meus_animais);
        instanciarComponentes();
        programarComponentes();
        procurarUsuarioAtual();
        recuperarDadosUsuario();
        //depurarListaAnimais(1);
    }

    @Override
    protected void onResume() {
        super.onResume();

        receberFeedback();
    }

    private void instanciarComponentes() {
        botaoMenu             = findViewById(R.id.botaoMenu);
        botaoCompartilhar     = findViewById(R.id.botaoCompartilhar);

        drlPagina             = findViewById(R.id.drlPagina);

        nvvMenu               = findViewById(R.id.nvvMenu);
        headerView            = nvvMenu.getHeaderView(0);

        txvMenuNomeUsuario    = headerView.findViewById(R.id.txvMenuNomeUsuario);
        imvMenuFotoUsuario    = headerView.findViewById(R.id.imvMenuFotoUsuario);
        menu                  = nvvMenu.getMenu();
        mnuInicial            = menu.findItem(R.id.menu_paginaInicial);
        mnuPerfil             = menu.findItem(R.id.menu_perfil);
        mnuAnimais            = menu.findItem(R.id.menu_meusAnimais);
        mnuMensagens          = menu.findItem(R.id.menu_mensagens);
        mnuOpcoes             = menu.findItem(R.id.menu_opcoes);
        mnuSair               = menu.findItem(R.id.menu_sair);

        fabAdicionar          = findViewById(R.id.fabAdicionar);

        llyListaVazia         = findViewById(R.id.llyListaVazia);
        btnCadastrarAnimal    = findViewById(R.id.btnCadastrarAnimal);

        cdvMeuAnimal1         = findViewById(R.id.cdvMeuAnimal1);
        imvMeuAnimal1         = findViewById(R.id.imvMeuAnimal1);
        txvNomeMeuAnimal1     = findViewById(R.id.txvNomeMeuAnimal1);
        txvIdadeMeuAnimal1    = findViewById(R.id.txvIdadeMeuAnimal1);
        txvRacaMeuAnimal1     = findViewById(R.id.txvRacaMeuAnimal1);
        cdvMeuAnimal2         = findViewById(R.id.cdvMeuAnimal2);
        imvMeuAnimal2         = findViewById(R.id.imvMeuAnimal2);
        txvNomeMeuAnimal2     = findViewById(R.id.txvNomeMeuAnimal2);
        txvIdadeMeuAnimal2    = findViewById(R.id.txvIdadeMeuAnimal2);
        txvRacaMeuAnimal2     = findViewById(R.id.txvRacaMeuAnimal2);
        cdvMeuAnimal3         = findViewById(R.id.cdvMeuAnimal3);
        imvMeuAnimal3         = findViewById(R.id.imvMeuAnimal3);
        txvNomeMeuAnimal3     = findViewById(R.id.txvNomeMeuAnimal3);
        txvIdadeMeuAnimal3    = findViewById(R.id.txvIdadeMeuAnimal3);
        txvRacaMeuAnimal3     = findViewById(R.id.txvRacaMeuAnimal3);
        cdvMeuAnimal4         = findViewById(R.id.cdvMeuAnimal4);
        imvMeuAnimal4         = findViewById(R.id.imvMeuAnimal4);
        txvNomeMeuAnimal4     = findViewById(R.id.txvNomeMeuAnimal4);
        txvIdadeMeuAnimal4    = findViewById(R.id.txvIdadeMeuAnimal4);
        txvRacaMeuAnimal4     = findViewById(R.id.txvRacaMeuAnimal4);
        cdvMeuAnimal5         = findViewById(R.id.cdvMeuAnimal5);
        imvMeuAnimal5         = findViewById(R.id.imvMeuAnimal5);
        txvNomeMeuAnimal5     = findViewById(R.id.txvNomeMeuAnimal5);
        txvIdadeMeuAnimal5    = findViewById(R.id.txvIdadeMeuAnimal5);
        txvRacaMeuAnimal5     = findViewById(R.id.txvRacaMeuAnimal5);
        cdvMeuAnimal6         = findViewById(R.id.cdvMeuAnimal6);
        imvMeuAnimal6         = findViewById(R.id.imvMeuAnimal6);
        txvNomeMeuAnimal6     = findViewById(R.id.txvNomeMeuAnimal6);
        txvIdadeMeuAnimal6    = findViewById(R.id.txvIdadeMeuAnimal6);
        txvRacaMeuAnimal6     = findViewById(R.id.txvRacaMeuAnimal6);
        cdvMeuAnimal7         = findViewById(R.id.cdvMeuAnimal7);
        imvMeuAnimal7         = findViewById(R.id.imvMeuAnimal7);
        txvNomeMeuAnimal7     = findViewById(R.id.txvNomeMeuAnimal7);
        txvIdadeMeuAnimal7    = findViewById(R.id.txvIdadeMeuAnimal7);
        txvRacaMeuAnimal7     = findViewById(R.id.txvRacaMeuAnimal7);
        cdvMeuAnimal8         = findViewById(R.id.cdvMeuAnimal8);
        imvMeuAnimal8         = findViewById(R.id.imvMeuAnimal8);
        txvNomeMeuAnimal8     = findViewById(R.id.txvNomeMeuAnimal8);
        txvIdadeMeuAnimal8    = findViewById(R.id.txvIdadeMeuAnimal8);
        txvRacaMeuAnimal8     = findViewById(R.id.txvRacaMeuAnimal8);
        cdvMeuAnimal9         = findViewById(R.id.cdvMeuAnimal9);
        imvMeuAnimal9         = findViewById(R.id.imvMeuAnimal9);
        txvNomeMeuAnimal9     = findViewById(R.id.txvNomeMeuAnimal9);
        txvIdadeMeuAnimal9    = findViewById(R.id.txvIdadeMeuAnimal9);
        txvRacaMeuAnimal9     = findViewById(R.id.txvRacaMeuAnimal9);
        cdvMeuAnimal10         = findViewById(R.id.cdvMeuAnimal10);
        imvMeuAnimal10         = findViewById(R.id.imvMeuAnimal10);
        txvNomeMeuAnimal10     = findViewById(R.id.txvNomeMeuAnimal10);
        txvIdadeMeuAnimal10    = findViewById(R.id.txvIdadeMeuAnimal10);
        txvRacaMeuAnimal10     = findViewById(R.id.txvRacaMeuAnimal10);
    }

    private void programarComponentes() {
        botaoMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drlPagina.openDrawer(GravityCompat.START);
            }
        });

        mnuInicial.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Intent telaInicial = new Intent(ListaMeusAnimais.this, TelaInicial.class);
                startActivity(telaInicial);
                return true;
            }
        });

        mnuPerfil.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Intent perfilUsuario = new Intent(ListaMeusAnimais.this, PerfilUsuario.class);
                startActivity(perfilUsuario);
                return true;
            }
        });

        mnuAnimais.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        mnuMensagens.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Toast.makeText(ListaMeusAnimais.this, "Funcionalidade ainda não implementada!", Toast.LENGTH_SHORT).show();
                return true;
            }
        });

        mnuOpcoes.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Intent telaOpcoes = new Intent(ListaMeusAnimais.this, TelaOpcoes.class);
                startActivity(telaOpcoes);
                return true;
            }
        });

        mnuSair.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                AlertDialog.Builder builder = new AlertDialog.Builder(ListaMeusAnimais.this);
                builder.setMessage("Deseja realmente encerrar a sessão?")
                        .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                drlPagina.closeDrawer(GravityCompat.START);
                                FirebaseAuth.getInstance().signOut();
                                Intent enviarFeedback = new Intent(ListaMeusAnimais.this, FormLogin.class);
                                enviarFeedback.putExtra("enviarFeedback", 3);
                                startActivity(enviarFeedback);
                                finish();
                            }
                        })
                        .setNegativeButton("Não", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {}
                        })
                        .create()
                        .show();
                return true;
            }
        });

        fabAdicionar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irTelaCadastroAnimal();
            }
        });
        btnCadastrarAnimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                irTelaCadastroAnimal();
            }
        });
    }

    private void procurarUsuarioAtual() {
        usuarioID                     = FirebaseAuth.getInstance().getCurrentUser().getUid();

        databaseRef                   = FirebaseDatabase.getInstance().getReference("uploads");
        storageRef                    = FirebaseStorage.getInstance().getReference("uploads");
        documentReference             = db.collection("Usuarios").document(usuarioID);
    }

    private void recuperarDadosUsuario() {
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (documentSnapshot != null){
                    txvMenuNomeUsuario.setText(documentSnapshot.getString("nome"));

                    carregarFotoUsuario();
                }
            }
        });
    }

    private void carregarFotoUsuario() {
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (documentSnapshot != null) {
                    String foto = documentSnapshot.getString("foto");
                    if (foto != null && !foto.isEmpty()){
                        imvMenuFotoUsuario.setBackgroundColor(getResources().getColor(R.color.transparent));
                        Picasso.get().load(documentSnapshot.getString("foto")).into(imvMenuFotoUsuario);
                    }
                }
            }
        });
    }

    private void depurarListaAnimais(int numListaAnimal) {
        llyListaVazia.setVisibility(View.GONE);
        switch (numListaAnimal) {
            case 1:
                cdvMeuAnimal1.setVisibility(View.VISIBLE);
                txvNomeMeuAnimal1.setText(R.string.test_placeholderName);
                txvIdadeMeuAnimal1.setText(R.string.test_placeholderValue);
                txvRacaMeuAnimal1.setText(R.string.test_placeholderText);
                break;
            case 2:
                cdvMeuAnimal2.setVisibility(View.VISIBLE);
                txvNomeMeuAnimal2.setText(R.string.test_placeholderName);
                txvIdadeMeuAnimal2.setText(R.string.test_placeholderValue);
                txvRacaMeuAnimal2.setText(R.string.test_placeholderText);
                break;
            case 3:
                cdvMeuAnimal3.setVisibility(View.VISIBLE);
                txvNomeMeuAnimal3.setText(R.string.test_placeholderName);
                txvIdadeMeuAnimal3.setText(R.string.test_placeholderValue);
                txvRacaMeuAnimal3.setText(R.string.test_placeholderText);
                break;
            case 4:
                cdvMeuAnimal4.setVisibility(View.VISIBLE);
                txvNomeMeuAnimal4.setText(R.string.test_placeholderName);
                txvIdadeMeuAnimal4.setText(R.string.test_placeholderValue);
                txvRacaMeuAnimal4.setText(R.string.test_placeholderText);
                break;
            case 5:
                cdvMeuAnimal5.setVisibility(View.VISIBLE);
                txvNomeMeuAnimal5.setText(R.string.test_placeholderName);
                txvIdadeMeuAnimal5.setText(R.string.test_placeholderValue);
                txvRacaMeuAnimal5.setText(R.string.test_placeholderText);
                break;
            case 6:
                cdvMeuAnimal6.setVisibility(View.VISIBLE);
                txvNomeMeuAnimal6.setText(R.string.test_placeholderName);
                txvIdadeMeuAnimal6.setText(R.string.test_placeholderValue);
                txvRacaMeuAnimal6.setText(R.string.test_placeholderText);
                break;
            case 7:
                cdvMeuAnimal7.setVisibility(View.VISIBLE);
                txvNomeMeuAnimal7.setText(R.string.test_placeholderName);
                txvIdadeMeuAnimal7.setText(R.string.test_placeholderValue);
                txvRacaMeuAnimal7.setText(R.string.test_placeholderText);
                break;
            case 8:
                cdvMeuAnimal8.setVisibility(View.VISIBLE);
                txvNomeMeuAnimal8.setText(R.string.test_placeholderName);
                txvIdadeMeuAnimal8.setText(R.string.test_placeholderValue);
                txvRacaMeuAnimal8.setText(R.string.test_placeholderText);
                break;
            case 9:
                cdvMeuAnimal9.setVisibility(View.VISIBLE);
                txvNomeMeuAnimal9.setText(R.string.test_placeholderName);
                txvIdadeMeuAnimal9.setText(R.string.test_placeholderValue);
                txvRacaMeuAnimal9.setText(R.string.test_placeholderText);
                break;
            case 10:
                cdvMeuAnimal10.setVisibility(View.VISIBLE);
                txvNomeMeuAnimal10.setText(R.string.test_placeholderName);
                txvIdadeMeuAnimal10.setText(R.string.test_placeholderValue);
                txvRacaMeuAnimal10.setText(R.string.test_placeholderText);
                break;
            default:
                System.out.println("ERRO AO DEPURAR LISTA!");
                break;
        }
    }

    private void irTelaCadastroAnimal() {
        Intent cadastroAnimal = new Intent(ListaMeusAnimais.this, FormCadastroAnimal.class);
        startActivity(cadastroAnimal);
    }

    private void receberFeedback(){
        Intent receberFeedback = getIntent();
        if(receberFeedback.getIntExtra("enviarFeedback", 0) == 1){
            Toast.makeText(ListaMeusAnimais.this, R.string.message_registerSuccess, Toast.LENGTH_SHORT).show();
        }
        receberFeedback.removeExtra("enviarFeedback");
    }

    @Override
    public void onBackPressed() {
        if (drlPagina.isDrawerOpen(GravityCompat.START)) {
            drlPagina.closeDrawer(GravityCompat.START);
        } else {
            finish();
        }
    }
}