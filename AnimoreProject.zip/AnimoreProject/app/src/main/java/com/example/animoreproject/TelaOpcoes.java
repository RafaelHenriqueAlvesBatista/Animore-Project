package com.example.animoreproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TelaOpcoes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opcoes);
    }
}