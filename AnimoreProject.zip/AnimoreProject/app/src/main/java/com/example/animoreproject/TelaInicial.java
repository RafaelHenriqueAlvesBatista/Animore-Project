package com.example.animoreproject;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.Objects;

public class TelaInicial extends AppCompatActivity {

    // ATRIBUTOS USUARIO
    private TextView txvNomeUsuario, atributoValorUsuario1, atributoValorUsuario2, atributoValorUsuario3;
    private ImageView imvFotoUsuario;

    // COMPONENTES MENU
    private NavigationView nvvMenu;
    private ImageButton botaoMenu, botaoCompartilhar;
    private TextView txvMenuNomeUsuario;

    // CAMPO BUSCA
    private ImageButton imbProcurarAnimais, imbProcurarMicrofone;
    private TextInputEditText edtBusca;

    // CAMPOS ANIMAIS EM DESTAQUE
    private ConstraintLayout clyAnimal1, clyAnimal2, clyAnimal3, clyAnimal4, clyAnimal5, clyAnimal6, clyAnimal7, clyAnimal8, clyAnimal9, clyAnimal10;
    private TextView txvNomeAnimal1, txvNomeAnimal2, txvNomeAnimal3, txvNomeAnimal4, txvNomeAnimal5, txvNomeAnimal6, txvNomeAnimal7, txvNomeAnimal8, txvNomeAnimal9, txvNomeAnimal10;
    private TextView txvIdadeAnimal1, txvIdadeAnimal2, txvIdadeAnimal3, txvIdadeAnimal4, txvIdadeAnimal5, txvIdadeAnimal6, txvIdadeAnimal7, txvIdadeAnimal8, txvIdadeAnimal9, txvIdadeAnimal10;
    private ImageView imvAnimal1, imvAnimal2, imvAnimal3, imvAnimal4, imvAnimal5, imvAnimal6, imvAnimal7, imvAnimal8, imvAnimal9, imvAnimal10;

    // ATRIBUTOS ANIMAIS EM DESTAQUE
    private ImageButton imvLikeAnimal1, imvDeslikeAnimal1, imvCoracaoAnimal1;
    private TextView txvLikesAnimal1, txvDeslikesAnimal1;
    private ImageButton imvLikeAnimal2, imvDeslikeAnimal2, imvCoracaoAnimal2;
    private TextView txvLikesAnimal2, txvDeslikesAnimal2;
    private ImageButton imvLikeAnimal3, imvDeslikeAnimal3, imvCoracaoAnimal3;
    private TextView txvLikesAnimal3, txvDeslikesAnimal3;
    private ImageButton imvLikeAnimal4, imvDeslikeAnimal4, imvCoracaoAnimal4;
    private TextView txvLikesAnimal4, txvDeslikesAnimal4;
    private ImageButton imvLikeAnimal5, imvDeslikeAnimal5, imvCoracaoAnimal5;
    private TextView txvLikesAnimal5, txvDeslikesAnimal5;
    private ImageButton imvLikeAnimal6, imvDeslikeAnimal6, imvCoracaoAnimal6;
    private TextView txvLikesAnimal6, txvDeslikesAnimal6;
    private ImageButton imvLikeAnimal7, imvDeslikeAnimal7, imvCoracaoAnimal7;
    private TextView txvLikesAnimal7, txvDeslikesAnimal7;
    private ImageButton imvLikeAnimal8, imvDeslikeAnimal8, imvCoracaoAnimal8;
    private TextView txvLikesAnimal8, txvDeslikesAnimal8;
    private ImageButton imvLikeAnimal9, imvDeslikeAnimal9, imvCoracaoAnimal9;
    private TextView txvLikesAnimal9, txvDeslikesAnimal9;
    private ImageButton imvLikeAnimal10, imvDeslikeAnimal10, imvCoracaoAnimal10;
    private TextView txvLikesAnimal10, txvDeslikesAnimal10;

    // ATRIBUTOS DO FIREBASE
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    String usuarioID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        txvNomeUsuario = findViewById(R.id.txvNomeUsuario);
        imvFotoUsuario = findViewById(R.id.imvFotoUsuario);

        nvvMenu = findViewById(R.id.nvvMenu);

        imvFotoUsuario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent perfilUsuario = new Intent(TelaInicial.this, PerfilUsuario.class);
                startActivity(perfilUsuario);
            }
        });
    }

    private void recuperarDados() {
        usuarioID = FirebaseAuth.getInstance().getCurrentUser().getUid();

        DocumentReference documentReference = db.collection("Usuarios").document(usuarioID);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (documentSnapshot != null){
                    txvNomeUsuario.setText(documentSnapshot.getString("nome"));
                    txvNomeUsuario.setText(documentSnapshot.getString("nome"));
                }
            }
        });
    }

    private void atualizarCargo() {
        Intent receberCargo = getIntent();
        String cargoEscolhido = receberCargo.getStringExtra("atualizarCargo");
        if (Objects.equals(cargoEscolhido, "d") || Objects.equals(cargoEscolhido, "a")){
            DocumentReference documentReference = db.collection("Usuarios").document(usuarioID);
            documentReference.update("cargo", cargoEscolhido);
        }
    }

    @Override
    public void onBackPressed(){
        finishAffinity();
    }
}