package com.example.animoreproject;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;

import java.util.Objects;

public class TelaInicial extends AppCompatActivity {

    private TextView txvNomeUsuario;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    String usuarioID;
    private ImageView imvFotoUsuario;
    private Button btnProcurarAnimais, btnProcurarAcessorios;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        txvNomeUsuario = findViewById(R.id.txvNomeUsuario);
        imvFotoUsuario = findViewById(R.id.imvFotoUsuario);
        btnProcurarAnimais = findViewById(R.id.btnProcurarAnimais);
        btnProcurarAcessorios = findViewById(R.id.btnProcurarAcessorios);

        imvFotoUsuario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent perfilUsuario = new Intent(TelaInicial.this, PerfilUsuario.class);
                startActivity(perfilUsuario);
            }
        });

        btnProcurarAnimais.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent procurarAnimais = new Intent(TelaInicial.this, TelaProcurar.class);
                procurarAnimais.putExtra("tituloProcurar", 1);
                startActivity(procurarAnimais);
            }
        });

        btnProcurarAcessorios.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent procurarAcessorios = new Intent(TelaInicial.this, TelaProcurar.class);
                procurarAcessorios.putExtra("tituloProcurar", 2);
                startActivity(procurarAcessorios);
            }
        });
    }
/*
    @Override
    protected void onStart() {
        super.onStart();

        usuarioID = FirebaseAuth.getInstance().getCurrentUser().getUid();

        DocumentReference documentReference = db.collection("Usuarios").document(usuarioID);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (documentSnapshot != null){
                    txvNomeUsuario.setText(documentSnapshot.getString("nome"));
                }
            }
        });

        atualizarCargo();
    }

    private void atualizarCargo() {
        Intent receberCargo = getIntent();
        String cargoEscolhido = receberCargo.getStringExtra("atualizarCargo");
        if (Objects.equals(cargoEscolhido, "d") || Objects.equals(cargoEscolhido, "a")){
            DocumentReference documentReference = db.collection("Usuarios").document(usuarioID);
            documentReference.update("cargo", cargoEscolhido);
        }
    }
*/
    @Override
    public void onBackPressed(){
        finishAffinity();
    }
}