package com.example.animoreproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class TelaInicial extends AppCompatActivity {

    // COMPONENTES TOOLBAR
    private ImageButton botaoMenu, botaoCompartilhar;

    // COMPONENTES TELA
    private DrawerLayout drlPagina;
    private View headerView;

    // COMPONENTES MENU
    private NavigationView nvvMenu;
    private TextView txvMenuNomeUsuario;
    private ImageView imvMenuFotoUsuario;
    private Menu menu;
    private MenuItem mnuInicial;
    private MenuItem mnuPerfil;
    private MenuItem mnuAnimais;
    private MenuItem mnuMensagens;
    private MenuItem mnuOpcoes;
    private MenuItem mnuSair;

    // ATRIBUTOS USUARIO
    private TextView txvNomeUsuario, atributoValorUsuario1, atributoValorUsuario2, atributoValorUsuario3;
    private ImageView imvFotoUsuario;

    // CAMPO BUSCA
    private ImageButton imbProcurarAnimais, imbProcurarMicrofone;
    private TextInputEditText edtBusca;

    // CAMPOS ANIMAIS EM DESTAQUE
    private ConstraintLayout clyAnimal1, clyAnimal2, clyAnimal3, clyAnimal4, clyAnimal5, clyAnimal6, clyAnimal7, clyAnimal8, clyAnimal9, clyAnimal10;
    private TextView txvNomeAnimal1, txvNomeAnimal2, txvNomeAnimal3, txvNomeAnimal4, txvNomeAnimal5, txvNomeAnimal6, txvNomeAnimal7, txvNomeAnimal8, txvNomeAnimal9, txvNomeAnimal10;
    private TextView txvIdadeAnimal1, txvIdadeAnimal2, txvIdadeAnimal3, txvIdadeAnimal4, txvIdadeAnimal5, txvIdadeAnimal6, txvIdadeAnimal7, txvIdadeAnimal8, txvIdadeAnimal9, txvIdadeAnimal10;
    private ImageView imvAnimal1, imvAnimal2, imvAnimal3, imvAnimal4, imvAnimal5, imvAnimal6, imvAnimal7, imvAnimal8, imvAnimal9, imvAnimal10;

    // ATRIBUTOS ANIMAIS EM DESTAQUE
    private ImageButton imvLikeAnimal1, imvDeslikeAnimal1, imvCoracaoAnimal1;
    private TextView txvLikesAnimal1, txvDeslikesAnimal1;
    private ImageButton imvLikeAnimal2, imvDeslikeAnimal2, imvCoracaoAnimal2;
    private TextView txvLikesAnimal2, txvDeslikesAnimal2;
    private ImageButton imvLikeAnimal3, imvDeslikeAnimal3, imvCoracaoAnimal3;
    private TextView txvLikesAnimal3, txvDeslikesAnimal3;
    private ImageButton imvLikeAnimal4, imvDeslikeAnimal4, imvCoracaoAnimal4;
    private TextView txvLikesAnimal4, txvDeslikesAnimal4;
    private ImageButton imvLikeAnimal5, imvDeslikeAnimal5, imvCoracaoAnimal5;
    private TextView txvLikesAnimal5, txvDeslikesAnimal5;
    private ImageButton imvLikeAnimal6, imvDeslikeAnimal6, imvCoracaoAnimal6;
    private TextView txvLikesAnimal6, txvDeslikesAnimal6;
    private ImageButton imvLikeAnimal7, imvDeslikeAnimal7, imvCoracaoAnimal7;
    private TextView txvLikesAnimal7, txvDeslikesAnimal7;
    private ImageButton imvLikeAnimal8, imvDeslikeAnimal8, imvCoracaoAnimal8;
    private TextView txvLikesAnimal8, txvDeslikesAnimal8;
    private ImageButton imvLikeAnimal9, imvDeslikeAnimal9, imvCoracaoAnimal9;
    private TextView txvLikesAnimal9, txvDeslikesAnimal9;
    private ImageButton imvLikeAnimal10, imvDeslikeAnimal10, imvCoracaoAnimal10;
    private TextView txvLikesAnimal10, txvDeslikesAnimal10;

    // CAMPOS ITENS EM ALTA
    private ConstraintLayout clyAcessorio1, clyAcessorio2, clyAcessorio3, clyAcessorio4, clyAcessorio5, clyAcessorio6, clyAcessorio7, clyAcessorio8, clyAcessorio9, clyAcessorio10;
    private TextView txvNomeAcessorio1, txvNomeAcessorio2, txvNomeAcessorio3, txvNomeAcessorio4, txvNomeAcessorio5, txvNomeAcessorio6, txvNomeAcessorio7, txvNomeAcessorio8, txvNomeAcessorio9, txvNomeAcessorio10;
    private ImageView imvAcessorio1, imvAcessorio2, imvAcessorio3, imvAcessorio4, imvAcessorio5, imvAcessorio6, imvAcessorio7, imvAcessorio8, imvAcessorio9, imvAcessorio10;

    // ATRIBUTOS ANIMAIS EM DESTAQUE
    private ImageButton imvBolsaAcessorio1, imvBolsaAcessorio2, imvBolsaAcessorio3, imvBolsaAcessorio4, imvBolsaAcessorio5, imvBolsaAcessorio6, imvBolsaAcessorio7, imvBolsaAcessorio8, imvBolsaAcessorio9, imvBolsaAcessorio10;
    private ImageButton imvInfoAcessorio1, imvInfoAcessorio2, imvInfoAcessorio3, imvInfoAcessorio4, imvInfoAcessorio5, imvInfoAcessorio6, imvInfoAcessorio7, imvInfoAcessorio8, imvInfoAcessorio9, imvInfoAcessorio10;

    // ATRIBUTOS DO FIREBASE
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    String usuarioID;
    private DocumentReference documentReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);
        procurarUsuarioAtual();
        instanciarComponentes();
        programarComponentes();
        recuperarDados();
        for (int i = 0; i <= 4; i++) {
            depurarListaAnimais(i);
        }
        for (int i = 0; i <= 4; i++) {
            depurarListaAcessorios(i);
        }
    }

    private void procurarUsuarioAtual() {
        usuarioID                     = FirebaseAuth.getInstance().getCurrentUser().getUid();

        documentReference             = db.collection("Usuarios").document(usuarioID);
    }

    private void instanciarComponentes() {
        botaoMenu             = findViewById(R.id.botaoMenu);
        botaoCompartilhar     = findViewById(R.id.botaoCompartilhar);

        drlPagina             = findViewById(R.id.drlPagina);

        nvvMenu               = findViewById(R.id.nvvMenu);
        headerView            = nvvMenu.getHeaderView(0);

        txvMenuNomeUsuario    = headerView.findViewById(R.id.txvMenuNomeUsuario);
        imvMenuFotoUsuario    = headerView.findViewById(R.id.imvMenuFotoUsuario);
        menu                  = nvvMenu.getMenu();
        mnuInicial            = menu.findItem(R.id.menu_paginaInicial);
        mnuPerfil             = menu.findItem(R.id.menu_perfil);
        mnuAnimais            = menu.findItem(R.id.menu_meusAnimais);
        mnuMensagens          = menu.findItem(R.id.menu_mensagens);
        mnuOpcoes             = menu.findItem(R.id.menu_opcoes);
        mnuSair               = menu.findItem(R.id.menu_sair);

        txvNomeUsuario        = findViewById(R.id.txvNomeUsuario);
        atributoValorUsuario1 = findViewById(R.id.atributoValorUsuario1);
        atributoValorUsuario2 = findViewById(R.id.atributoValorUsuario2);
        atributoValorUsuario3 = findViewById(R.id.atributoValorUsuario3);
        imvFotoUsuario        = findViewById(R.id.imvFotoUsuario);

        imbProcurarAnimais    = findViewById(R.id.imbProcurarAnimais);
        imbProcurarMicrofone  = findViewById(R.id.imbProcurarMicrofone);
        edtBusca              = findViewById(R.id.edtBusca);

        clyAnimal1            = findViewById(R.id.clyAnimal1);
        txvNomeAnimal1        = findViewById(R.id.txvNomeAnimal1);
        txvIdadeAnimal1       = findViewById(R.id.txvIdadeAnimal1);
        imvAnimal1            = findViewById(R.id.imvAnimal1);
        imvLikeAnimal1        = findViewById(R.id.imvLikeAnimal1);
        txvLikesAnimal1       = findViewById(R.id.txvLikesAnimal1);
        imvDeslikeAnimal1     = findViewById(R.id.imvDeslikeAnimal1);
        txvDeslikesAnimal1    = findViewById(R.id.txvDeslikesAnimal1);
        imvCoracaoAnimal1     = findViewById(R.id.imvCoracaoAnimal1);
        clyAnimal2            = findViewById(R.id.clyAnimal2);
        txvNomeAnimal2        = findViewById(R.id.txvNomeAnimal2);
        txvIdadeAnimal2       = findViewById(R.id.txvIdadeAnimal2);
        imvAnimal2            = findViewById(R.id.imvAnimal2);
        imvLikeAnimal2        = findViewById(R.id.imvLikeAnimal2);
        txvLikesAnimal2       = findViewById(R.id.txvLikesAnimal2);
        imvDeslikeAnimal2     = findViewById(R.id.imvDeslikeAnimal2);
        txvDeslikesAnimal2    = findViewById(R.id.txvDeslikesAnimal2);
        imvCoracaoAnimal2     = findViewById(R.id.imvCoracaoAnimal2);
        clyAnimal3            = findViewById(R.id.clyAnimal3);
        txvNomeAnimal3        = findViewById(R.id.txvNomeAnimal3);
        txvIdadeAnimal3       = findViewById(R.id.txvIdadeAnimal3);
        imvAnimal3            = findViewById(R.id.imvAnimal3);
        imvLikeAnimal3        = findViewById(R.id.imvLikeAnimal3);
        txvLikesAnimal3       = findViewById(R.id.txvLikesAnimal3);
        imvDeslikeAnimal3     = findViewById(R.id.imvDeslikeAnimal3);
        txvDeslikesAnimal3    = findViewById(R.id.txvDeslikesAnimal3);
        imvCoracaoAnimal3     = findViewById(R.id.imvCoracaoAnimal3);
        clyAnimal4            = findViewById(R.id.clyAnimal4);
        txvNomeAnimal4        = findViewById(R.id.txvNomeAnimal4);
        txvIdadeAnimal4       = findViewById(R.id.txvIdadeAnimal4);
        imvAnimal4            = findViewById(R.id.imvAnimal4);
        imvLikeAnimal4        = findViewById(R.id.imvLikeAnimal4);
        txvLikesAnimal4       = findViewById(R.id.txvLikesAnimal4);
        imvDeslikeAnimal4     = findViewById(R.id.imvDeslikeAnimal4);
        txvDeslikesAnimal4    = findViewById(R.id.txvDeslikesAnimal4);
        imvCoracaoAnimal4     = findViewById(R.id.imvCoracaoAnimal4);
        clyAnimal5            = findViewById(R.id.clyAnimal5);
        txvNomeAnimal5        = findViewById(R.id.txvNomeAnimal5);
        txvIdadeAnimal5       = findViewById(R.id.txvIdadeAnimal5);
        imvAnimal5            = findViewById(R.id.imvAnimal5);
        imvLikeAnimal5        = findViewById(R.id.imvLikeAnimal5);
        txvLikesAnimal5       = findViewById(R.id.txvLikesAnimal5);
        imvDeslikeAnimal5     = findViewById(R.id.imvDeslikeAnimal5);
        txvDeslikesAnimal5    = findViewById(R.id.txvDeslikesAnimal5);
        imvCoracaoAnimal5     = findViewById(R.id.imvCoracaoAnimal5);
        clyAnimal6            = findViewById(R.id.clyAnimal6);
        txvNomeAnimal6        = findViewById(R.id.txvNomeAnimal6);
        txvIdadeAnimal6       = findViewById(R.id.txvIdadeAnimal6);
        imvAnimal6            = findViewById(R.id.imvAnimal6);
        imvLikeAnimal6        = findViewById(R.id.imvLikeAnimal6);
        txvLikesAnimal6       = findViewById(R.id.txvLikesAnimal6);
        imvDeslikeAnimal6     = findViewById(R.id.imvDeslikeAnimal6);
        txvDeslikesAnimal6    = findViewById(R.id.txvDeslikesAnimal6);
        imvCoracaoAnimal6     = findViewById(R.id.imvCoracaoAnimal6);
        clyAnimal7            = findViewById(R.id.clyAnimal7);
        txvNomeAnimal7        = findViewById(R.id.txvNomeAnimal7);
        txvIdadeAnimal7       = findViewById(R.id.txvIdadeAnimal7);
        imvAnimal7            = findViewById(R.id.imvAnimal7);
        imvLikeAnimal7        = findViewById(R.id.imvLikeAnimal7);
        txvLikesAnimal7       = findViewById(R.id.txvLikesAnimal7);
        imvDeslikeAnimal7     = findViewById(R.id.imvDeslikeAnimal7);
        txvDeslikesAnimal7    = findViewById(R.id.txvDeslikesAnimal7);
        imvCoracaoAnimal7     = findViewById(R.id.imvCoracaoAnimal7);
        clyAnimal8            = findViewById(R.id.clyAnimal8);
        txvNomeAnimal8        = findViewById(R.id.txvNomeAnimal8);
        txvIdadeAnimal8       = findViewById(R.id.txvIdadeAnimal8);
        imvAnimal8            = findViewById(R.id.imvAnimal8);
        imvLikeAnimal8        = findViewById(R.id.imvLikeAnimal8);
        txvLikesAnimal8       = findViewById(R.id.txvLikesAnimal8);
        imvDeslikeAnimal8     = findViewById(R.id.imvDeslikeAnimal8);
        txvDeslikesAnimal8    = findViewById(R.id.txvDeslikesAnimal8);
        imvCoracaoAnimal8     = findViewById(R.id.imvCoracaoAnimal8);
        clyAnimal9            = findViewById(R.id.clyAnimal9);
        txvNomeAnimal9        = findViewById(R.id.txvNomeAnimal9);
        txvIdadeAnimal9       = findViewById(R.id.txvIdadeAnimal9);
        imvAnimal9            = findViewById(R.id.imvAnimal9);
        imvLikeAnimal9        = findViewById(R.id.imvLikeAnimal9);
        txvLikesAnimal9       = findViewById(R.id.txvLikesAnimal9);
        imvDeslikeAnimal9     = findViewById(R.id.imvDeslikeAnimal9);
        txvDeslikesAnimal9    = findViewById(R.id.txvDeslikesAnimal9);
        imvCoracaoAnimal9     = findViewById(R.id.imvCoracaoAnimal9);
        clyAnimal10           = findViewById(R.id.clyAnimal10);
        txvNomeAnimal10       = findViewById(R.id.txvNomeAnimal10);
        txvIdadeAnimal10      = findViewById(R.id.txvIdadeAnimal10);
        imvAnimal10           = findViewById(R.id.imvAnimal10);
        imvLikeAnimal10       = findViewById(R.id.imvLikeAnimal10);
        txvLikesAnimal10      = findViewById(R.id.txvLikesAnimal10);
        imvDeslikeAnimal10    = findViewById(R.id.imvDeslikeAnimal10);
        txvDeslikesAnimal10   = findViewById(R.id.txvDeslikesAnimal10);
        imvCoracaoAnimal10    = findViewById(R.id.imvCoracaoAnimal10);

        clyAcessorio1         = findViewById(R.id.clyAcessorio1);
        txvNomeAcessorio1     = findViewById(R.id.txvNomeAcessorio1);
        imvAcessorio1         = findViewById(R.id.imvAcessorio1);
        imvBolsaAcessorio1    = findViewById(R.id.imvBolsaAcessorio1);
        imvInfoAcessorio1     = findViewById(R.id.imvInfoAcessorio1);
        clyAcessorio2         = findViewById(R.id.clyAcessorio2);
        txvNomeAcessorio2     = findViewById(R.id.txvNomeAcessorio2);
        imvAcessorio2         = findViewById(R.id.imvAcessorio2);
        imvBolsaAcessorio2    = findViewById(R.id.imvBolsaAcessorio2);
        imvInfoAcessorio2     = findViewById(R.id.imvInfoAcessorio2);
        clyAcessorio3         = findViewById(R.id.clyAcessorio3);
        txvNomeAcessorio3     = findViewById(R.id.txvNomeAcessorio3);
        imvAcessorio3         = findViewById(R.id.imvAcessorio3);
        imvBolsaAcessorio3    = findViewById(R.id.imvBolsaAcessorio3);
        imvInfoAcessorio3     = findViewById(R.id.imvInfoAcessorio3);
        clyAcessorio4         = findViewById(R.id.clyAcessorio4);
        txvNomeAcessorio4     = findViewById(R.id.txvNomeAcessorio4);
        imvAcessorio4         = findViewById(R.id.imvAcessorio4);
        imvBolsaAcessorio4    = findViewById(R.id.imvBolsaAcessorio4);
        imvInfoAcessorio4     = findViewById(R.id.imvInfoAcessorio4);
        clyAcessorio5         = findViewById(R.id.clyAcessorio5);
        txvNomeAcessorio5     = findViewById(R.id.txvNomeAcessorio5);
        imvAcessorio5         = findViewById(R.id.imvAcessorio5);
        imvBolsaAcessorio5    = findViewById(R.id.imvBolsaAcessorio5);
        imvInfoAcessorio5     = findViewById(R.id.imvInfoAcessorio5);
        clyAcessorio6         = findViewById(R.id.clyAcessorio6);
        txvNomeAcessorio6     = findViewById(R.id.txvNomeAcessorio6);
        imvAcessorio6         = findViewById(R.id.imvAcessorio6);
        imvBolsaAcessorio6    = findViewById(R.id.imvBolsaAcessorio6);
        imvInfoAcessorio6     = findViewById(R.id.imvInfoAcessorio6);
        clyAcessorio7         = findViewById(R.id.clyAcessorio7);
        txvNomeAcessorio7     = findViewById(R.id.txvNomeAcessorio7);
        imvAcessorio7         = findViewById(R.id.imvAcessorio7);
        imvBolsaAcessorio7    = findViewById(R.id.imvBolsaAcessorio7);
        imvInfoAcessorio7     = findViewById(R.id.imvInfoAcessorio7);
        clyAcessorio8         = findViewById(R.id.clyAcessorio8);
        txvNomeAcessorio8     = findViewById(R.id.txvNomeAcessorio8);
        imvAcessorio8         = findViewById(R.id.imvAcessorio8);
        imvBolsaAcessorio8    = findViewById(R.id.imvBolsaAcessorio8);
        imvInfoAcessorio8     = findViewById(R.id.imvInfoAcessorio8);
        clyAcessorio9         = findViewById(R.id.clyAcessorio9);
        txvNomeAcessorio9     = findViewById(R.id.txvNomeAcessorio9);
        imvAcessorio9         = findViewById(R.id.imvAcessorio9);
        imvBolsaAcessorio9    = findViewById(R.id.imvBolsaAcessorio9);
        imvInfoAcessorio9     = findViewById(R.id.imvInfoAcessorio9);
        clyAcessorio10        = findViewById(R.id.clyAcessorio10);
        txvNomeAcessorio10    = findViewById(R.id.txvNomeAcessorio10);
        imvAcessorio10        = findViewById(R.id.imvAcessorio10);
        imvBolsaAcessorio10   = findViewById(R.id.imvBolsaAcessorio10);
        imvInfoAcessorio10    = findViewById(R.id.imvInfoAcessorio10);
    }

    private void programarComponentes() {
        botaoMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drlPagina.openDrawer(GravityCompat.START);
            }
        });

        mnuInicial.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        mnuPerfil.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Intent perfilUsuario = new Intent(TelaInicial.this, PerfilUsuario.class);
                startActivity(perfilUsuario);
                return true;
            }
        });

        mnuAnimais.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Intent meusAnimais = new Intent(TelaInicial.this, ListaMeusAnimais.class);
                startActivity(meusAnimais);
                return true;
            }
        });

        mnuMensagens.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Toast.makeText(TelaInicial.this, "Funcionalidade ainda não implementada!", Toast.LENGTH_SHORT).show();
                return true;
            }
        });

        mnuOpcoes.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Intent telaOpcoes = new Intent(TelaInicial.this, TelaOpcoes.class);
                startActivity(telaOpcoes);
                return true;
            }
        });

        mnuSair.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                AlertDialog.Builder builder = new AlertDialog.Builder(TelaInicial.this);
                builder.setMessage("Deseja realmente encerrar a sessão?")
                        .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                drlPagina.closeDrawer(GravityCompat.START);
                                FirebaseAuth.getInstance().signOut();
                                Intent enviarFeedback = new Intent(TelaInicial.this, FormLogin.class);
                                enviarFeedback.putExtra("enviarFeedback", 3);
                                startActivity(enviarFeedback);
                                finish();
                            }
                        })
                        .setNegativeButton("Não", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {}
                        })
                        .create()
                        .show();
                return true;
            }
        });

        txvNomeUsuario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent perfilUsuario = new Intent(TelaInicial.this, PerfilUsuario.class);
                startActivity(perfilUsuario);
            }
        });
        imvFotoUsuario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent perfilUsuario = new Intent(TelaInicial.this, PerfilUsuario.class);
                startActivity(perfilUsuario);
            }
        });
    }

    private void recuperarDados() {
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (documentSnapshot != null){
                    txvNomeUsuario.setText(documentSnapshot.getString("nome"));
                    atributoValorUsuario1.setText(documentSnapshot.getString("numAnimais"));
                    atributoValorUsuario2.setText(documentSnapshot.getString("curtidas"));
                    atributoValorUsuario3.setText(documentSnapshot.getString("seguidores"));

                    txvMenuNomeUsuario.setText(documentSnapshot.getString("nome"));

                    carregarFoto();
                }
            }
        });
    }

    private void carregarFoto() {
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (documentSnapshot != null) {
                    String foto = documentSnapshot.getString("foto");
                    if (foto != null && !foto.isEmpty()){
                        imvFotoUsuario.setBackgroundColor(getResources().getColor(R.color.transparent));
                        imvMenuFotoUsuario.setBackgroundColor(getResources().getColor(R.color.transparent));
                        Picasso.get().load(documentSnapshot.getString("foto")).into(imvFotoUsuario);
                        Picasso.get().load(documentSnapshot.getString("foto")).into(imvMenuFotoUsuario);
                    }
                }
            }
        });
    }

    private void depurarListaAnimais(int numListaAnimal) {
        switch (numListaAnimal) {
            case 1:
                clyAnimal1.setVisibility(View.VISIBLE);
                imvAnimal1.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAnimal1.setText(R.string.test_placeholderName);
                txvIdadeAnimal1.setText(R.string.test_placeholderValue);
                txvLikesAnimal1.setText(R.string.test_placeholderValue);
                txvDeslikesAnimal1.setText(R.string.test_placeholderValue);
                break;
            case 2:
                clyAnimal2.setVisibility(View.VISIBLE);
                imvAnimal2.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAnimal2.setText(R.string.test_placeholderName);
                txvIdadeAnimal2.setText(R.string.test_placeholderValue);
                txvLikesAnimal2.setText(R.string.test_placeholderValue);
                txvDeslikesAnimal2.setText(R.string.test_placeholderValue);
                break;
            case 3:
                clyAnimal3.setVisibility(View.VISIBLE);
                imvAnimal3.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAnimal3.setText(R.string.test_placeholderName);
                txvIdadeAnimal3.setText(R.string.test_placeholderValue);
                txvLikesAnimal3.setText(R.string.test_placeholderValue);
                txvDeslikesAnimal3.setText(R.string.test_placeholderValue);
                break;
            case 4:
                clyAnimal4.setVisibility(View.VISIBLE);
                imvAnimal4.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAnimal4.setText(R.string.test_placeholderName);
                txvIdadeAnimal4.setText(R.string.test_placeholderValue);
                txvLikesAnimal4.setText(R.string.test_placeholderValue);
                txvDeslikesAnimal4.setText(R.string.test_placeholderValue);
                break;
            case 5:
                clyAnimal5.setVisibility(View.VISIBLE);
                imvAnimal5.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAnimal5.setText(R.string.test_placeholderName);
                txvIdadeAnimal5.setText(R.string.test_placeholderValue);
                txvLikesAnimal5.setText(R.string.test_placeholderValue);
                txvDeslikesAnimal5.setText(R.string.test_placeholderValue);
                break;
            case 6:
                clyAnimal6.setVisibility(View.VISIBLE);
                imvAnimal6.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAnimal6.setText(R.string.test_placeholderName);
                txvIdadeAnimal6.setText(R.string.test_placeholderValue);
                txvLikesAnimal6.setText(R.string.test_placeholderValue);
                txvDeslikesAnimal6.setText(R.string.test_placeholderValue);
                break;
            case 7:
                clyAnimal7.setVisibility(View.VISIBLE);
                imvAnimal7.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAnimal7.setText(R.string.test_placeholderName);
                txvIdadeAnimal7.setText(R.string.test_placeholderValue);
                txvLikesAnimal7.setText(R.string.test_placeholderValue);
                txvDeslikesAnimal7.setText(R.string.test_placeholderValue);
                break;
            case 8:
                clyAnimal8.setVisibility(View.VISIBLE);
                imvAnimal8.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAnimal8.setText(R.string.test_placeholderName);
                txvIdadeAnimal8.setText(R.string.test_placeholderValue);
                txvLikesAnimal8.setText(R.string.test_placeholderValue);
                txvDeslikesAnimal8.setText(R.string.test_placeholderValue);
                break;
            case 9:
                clyAnimal9.setVisibility(View.VISIBLE);
                imvAnimal9.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAnimal9.setText(R.string.test_placeholderName);
                txvIdadeAnimal9.setText(R.string.test_placeholderValue);
                txvLikesAnimal9.setText(R.string.test_placeholderValue);
                txvDeslikesAnimal9.setText(R.string.test_placeholderValue);
                break;
            case 10:
                clyAnimal10.setVisibility(View.VISIBLE);
                imvAnimal10.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAnimal10.setText(R.string.test_placeholderName);
                txvIdadeAnimal10.setText(R.string.test_placeholderValue);
                txvLikesAnimal10.setText(R.string.test_placeholderValue);
                txvDeslikesAnimal10.setText(R.string.test_placeholderValue);
                break;
            default:
                System.out.println("ERRO AO DEPURAR LISTA!");
                break;
        }
    }

    private void depurarListaAcessorios(int numListaAcessorio) {
        switch (numListaAcessorio) {
            case 1:
                clyAcessorio1.setVisibility(View.VISIBLE);
                imvAcessorio1.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAcessorio1.setText(R.string.test_placeholderText);
                break;
            case 2:
                clyAcessorio2.setVisibility(View.VISIBLE);
                imvAcessorio2.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAcessorio2.setText(R.string.test_placeholderText);
                break;
            case 3:
                clyAcessorio3.setVisibility(View.VISIBLE);
                imvAcessorio3.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAcessorio3.setText(R.string.test_placeholderText);
                break;
            case 4:
                clyAcessorio4.setVisibility(View.VISIBLE);
                imvAcessorio4.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAcessorio4.setText(R.string.test_placeholderText);
                break;
            case 5:
                clyAcessorio5.setVisibility(View.VISIBLE);
                imvAcessorio5.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAcessorio5.setText(R.string.test_placeholderText);
                break;
            case 6:
                clyAcessorio6.setVisibility(View.VISIBLE);
                imvAcessorio6.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAcessorio6.setText(R.string.test_placeholderText);
                break;
            case 7:
                clyAcessorio7.setVisibility(View.VISIBLE);
                imvAcessorio7.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAcessorio7.setText(R.string.test_placeholderText);
                break;
            case 8:
                clyAcessorio8.setVisibility(View.VISIBLE);
                imvAcessorio8.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAcessorio8.setText(R.string.test_placeholderText);
                break;
            case 9:
                clyAcessorio9.setVisibility(View.VISIBLE);
                imvAcessorio9.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAcessorio9.setText(R.string.test_placeholderText);
                break;
            case 10:
                clyAcessorio10.setVisibility(View.VISIBLE);
                imvAcessorio10.setBackground(AppCompatResources.getDrawable(TelaInicial.this, R.drawable.ic_launcher_background));
                txvNomeAcessorio10.setText(R.string.test_placeholderText);
                break;
            default:
                System.out.println("ERRO AO DEPURAR LISTA!");
                break;
        }
    }

    @Override
    public void onBackPressed(){
        if (drlPagina.isDrawerOpen(GravityCompat.START)) {
            drlPagina.closeDrawer(GravityCompat.START);
        } else {
            finishAffinity();
        }
    }
}