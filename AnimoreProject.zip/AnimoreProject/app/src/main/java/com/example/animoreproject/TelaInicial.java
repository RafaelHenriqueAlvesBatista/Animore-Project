package com.example.animoreproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.Objects;

public class TelaInicial extends AppCompatActivity {

    // COMPONENTES TOOLBAR
    private ImageButton botaoMenu, botaoCompartilhar;

    // COMPONENTES TELA
    private DrawerLayout drlPagina;
    private View headerView;

    // COMPONENTES MENU
    private NavigationView nvvMenu;
    private TextView txvMenuNomeUsuario;
    private ImageView imvMenuFotoUsuario;
    private Menu menu;
    private MenuItem mnuInicial;
    private MenuItem mnuPerfil;
    private MenuItem mnuAnimais;
    private MenuItem mnuMensagens;
    private MenuItem mnuOpcoes;
    private MenuItem mnuSair;

    // ATRIBUTOS USUARIO
    private TextView txvNomeUsuario, atributoValorUsuario1, atributoValorUsuario2, atributoValorUsuario3;
    private ImageView imvFotoUsuario;

    // CAMPO BUSCA
    private ImageButton imbProcurarAnimais, imbProcurarMicrofone;
    private TextInputEditText edtBusca;

    // CAMPOS ANIMAIS EM DESTAQUE
    private ConstraintLayout clyAnimal1, clyAnimal2, clyAnimal3, clyAnimal4, clyAnimal5, clyAnimal6, clyAnimal7, clyAnimal8, clyAnimal9, clyAnimal10;
    private TextView txvNomeAnimal1, txvNomeAnimal2, txvNomeAnimal3, txvNomeAnimal4, txvNomeAnimal5, txvNomeAnimal6, txvNomeAnimal7, txvNomeAnimal8, txvNomeAnimal9, txvNomeAnimal10;
    private TextView txvIdadeAnimal1, txvIdadeAnimal2, txvIdadeAnimal3, txvIdadeAnimal4, txvIdadeAnimal5, txvIdadeAnimal6, txvIdadeAnimal7, txvIdadeAnimal8, txvIdadeAnimal9, txvIdadeAnimal10;
    private ImageView imvAnimal1, imvAnimal2, imvAnimal3, imvAnimal4, imvAnimal5, imvAnimal6, imvAnimal7, imvAnimal8, imvAnimal9, imvAnimal10;

    // ATRIBUTOS ANIMAIS EM DESTAQUE
    private ImageButton imvLikeAnimal1, imvDeslikeAnimal1, imvCoracaoAnimal1;
    private TextView txvLikesAnimal1, txvDeslikesAnimal1;
    private ImageButton imvLikeAnimal2, imvDeslikeAnimal2, imvCoracaoAnimal2;
    private TextView txvLikesAnimal2, txvDeslikesAnimal2;
    private ImageButton imvLikeAnimal3, imvDeslikeAnimal3, imvCoracaoAnimal3;
    private TextView txvLikesAnimal3, txvDeslikesAnimal3;
    private ImageButton imvLikeAnimal4, imvDeslikeAnimal4, imvCoracaoAnimal4;
    private TextView txvLikesAnimal4, txvDeslikesAnimal4;
    private ImageButton imvLikeAnimal5, imvDeslikeAnimal5, imvCoracaoAnimal5;
    private TextView txvLikesAnimal5, txvDeslikesAnimal5;
    private ImageButton imvLikeAnimal6, imvDeslikeAnimal6, imvCoracaoAnimal6;
    private TextView txvLikesAnimal6, txvDeslikesAnimal6;
    private ImageButton imvLikeAnimal7, imvDeslikeAnimal7, imvCoracaoAnimal7;
    private TextView txvLikesAnimal7, txvDeslikesAnimal7;
    private ImageButton imvLikeAnimal8, imvDeslikeAnimal8, imvCoracaoAnimal8;
    private TextView txvLikesAnimal8, txvDeslikesAnimal8;
    private ImageButton imvLikeAnimal9, imvDeslikeAnimal9, imvCoracaoAnimal9;
    private TextView txvLikesAnimal9, txvDeslikesAnimal9;
    private ImageButton imvLikeAnimal10, imvDeslikeAnimal10, imvCoracaoAnimal10;
    private TextView txvLikesAnimal10, txvDeslikesAnimal10;

    // ATRIBUTOS DO FIREBASE
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    String usuarioID;
    private DatabaseReference databaseRef;
    private StorageReference storageRef;
    private DocumentReference documentReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);
        procurarUsuarioAtual();
        instanciarComponentes();
        programarComponentes();
        recuperarDados();
    }

    private void procurarUsuarioAtual() {
        usuarioID                     = FirebaseAuth.getInstance().getCurrentUser().getUid();

        databaseRef                   = FirebaseDatabase.getInstance().getReference("uploads");
        storageRef                    = FirebaseStorage.getInstance().getReference("uploads");
        documentReference             = db.collection("Usuarios").document(usuarioID);
    }

    private void instanciarComponentes() {
        botaoMenu             = findViewById(R.id.botaoMenu);
        botaoCompartilhar     = findViewById(R.id.botaoCompartilhar);

        drlPagina             = findViewById(R.id.drlPagina);

        nvvMenu               = findViewById(R.id.nvvMenu);
        headerView            = nvvMenu.getHeaderView(0);

        txvMenuNomeUsuario    = headerView.findViewById(R.id.txvMenuNomeUsuario);
        imvMenuFotoUsuario    = headerView.findViewById(R.id.imvMenuFotoUsuario);
        menu                  = nvvMenu.getMenu();
        mnuInicial            = menu.findItem(R.id.menu_paginaInicial);
        mnuPerfil             = menu.findItem(R.id.menu_perfil);
        mnuAnimais            = menu.findItem(R.id.menu_meusAnimais);
        mnuMensagens          = menu.findItem(R.id.menu_mensagens);
        mnuOpcoes             = menu.findItem(R.id.menu_opcoes);
        mnuSair               = menu.findItem(R.id.menu_sair);

        txvNomeUsuario        = findViewById(R.id.txvNomeUsuario);
        atributoValorUsuario1 = findViewById(R.id.atributoValorUsuario1);
        atributoValorUsuario2 = findViewById(R.id.atributoValorUsuario2);
        atributoValorUsuario3 = findViewById(R.id.atributoValorUsuario3);
        imvFotoUsuario        = findViewById(R.id.imvFotoUsuario);

        imbProcurarAnimais    = findViewById(R.id.imbProcurarAnimais);
        imbProcurarMicrofone  = findViewById(R.id.imbProcurarMicrofone);
        edtBusca              = findViewById(R.id.edtBusca);

        clyAnimal1            = findViewById(R.id.clyAnimal1);
        txvNomeAnimal1        = findViewById(R.id.txvNomeAnimal1);
        txvIdadeAnimal1       = findViewById(R.id.txvIdadeAnimal1);
        imvAnimal1            = findViewById(R.id.imvAnimal1);
        imvLikeAnimal1        = findViewById(R.id.imvLikeAnimal1);
        txvLikesAnimal1       = findViewById(R.id.txvLikesAnimal1);
        imvDeslikeAnimal1     = findViewById(R.id.imvDeslikeAnimal1);
        txvDeslikesAnimal1    = findViewById(R.id.txvDeslikesAnimal1);
        imvCoracaoAnimal1     = findViewById(R.id.imvCoracaoAnimal1);
        clyAnimal2            = findViewById(R.id.clyAnimal2);
        txvNomeAnimal2        = findViewById(R.id.txvNomeAnimal2);
        txvIdadeAnimal2       = findViewById(R.id.txvIdadeAnimal2);
        imvAnimal2            = findViewById(R.id.imvAnimal2);
        imvLikeAnimal2        = findViewById(R.id.imvLikeAnimal2);
        txvLikesAnimal2       = findViewById(R.id.txvLikesAnimal2);
        imvDeslikeAnimal2     = findViewById(R.id.imvDeslikeAnimal2);
        txvDeslikesAnimal2    = findViewById(R.id.txvDeslikesAnimal2);
        imvCoracaoAnimal2     = findViewById(R.id.imvCoracaoAnimal2);
        clyAnimal3            = findViewById(R.id.clyAnimal3);
        txvNomeAnimal3        = findViewById(R.id.txvNomeAnimal3);
        txvIdadeAnimal3       = findViewById(R.id.txvIdadeAnimal3);
        imvAnimal3            = findViewById(R.id.imvAnimal3);
        imvLikeAnimal3        = findViewById(R.id.imvLikeAnimal3);
        txvLikesAnimal3       = findViewById(R.id.txvLikesAnimal3);
        imvDeslikeAnimal3     = findViewById(R.id.imvDeslikeAnimal3);
        txvDeslikesAnimal3    = findViewById(R.id.txvDeslikesAnimal3);
        imvCoracaoAnimal3     = findViewById(R.id.imvCoracaoAnimal3);
        clyAnimal4            = findViewById(R.id.clyAnimal4);
        txvNomeAnimal4        = findViewById(R.id.txvNomeAnimal4);
        txvIdadeAnimal4       = findViewById(R.id.txvIdadeAnimal4);
        imvAnimal4            = findViewById(R.id.imvAnimal4);
        imvLikeAnimal4        = findViewById(R.id.imvLikeAnimal4);
        txvLikesAnimal4       = findViewById(R.id.txvLikesAnimal4);
        imvDeslikeAnimal4     = findViewById(R.id.imvDeslikeAnimal4);
        txvDeslikesAnimal4    = findViewById(R.id.txvDeslikesAnimal4);
        imvCoracaoAnimal4     = findViewById(R.id.imvCoracaoAnimal4);
        clyAnimal5            = findViewById(R.id.clyAnimal5);
        txvNomeAnimal5        = findViewById(R.id.txvNomeAnimal5);
        txvIdadeAnimal5       = findViewById(R.id.txvIdadeAnimal5);
        imvAnimal5            = findViewById(R.id.imvAnimal5);
        imvLikeAnimal5        = findViewById(R.id.imvLikeAnimal5);
        txvLikesAnimal5       = findViewById(R.id.txvLikesAnimal5);
        imvDeslikeAnimal5     = findViewById(R.id.imvDeslikeAnimal5);
        txvDeslikesAnimal5    = findViewById(R.id.txvDeslikesAnimal5);
        imvCoracaoAnimal5     = findViewById(R.id.imvCoracaoAnimal5);
        clyAnimal6            = findViewById(R.id.clyAnimal6);
        txvNomeAnimal6        = findViewById(R.id.txvNomeAnimal6);
        txvIdadeAnimal6       = findViewById(R.id.txvIdadeAnimal6);
        imvAnimal6            = findViewById(R.id.imvAnimal6);
        imvLikeAnimal6        = findViewById(R.id.imvLikeAnimal6);
        txvLikesAnimal6       = findViewById(R.id.txvLikesAnimal6);
        imvDeslikeAnimal6     = findViewById(R.id.imvDeslikeAnimal6);
        txvDeslikesAnimal6    = findViewById(R.id.txvDeslikesAnimal6);
        imvCoracaoAnimal6     = findViewById(R.id.imvCoracaoAnimal6);
        clyAnimal7            = findViewById(R.id.clyAnimal7);
        txvNomeAnimal7        = findViewById(R.id.txvNomeAnimal7);
        txvIdadeAnimal7       = findViewById(R.id.txvIdadeAnimal7);
        imvAnimal7            = findViewById(R.id.imvAnimal7);
        imvLikeAnimal7        = findViewById(R.id.imvLikeAnimal7);
        txvLikesAnimal7       = findViewById(R.id.txvLikesAnimal7);
        imvDeslikeAnimal7     = findViewById(R.id.imvDeslikeAnimal7);
        txvDeslikesAnimal7    = findViewById(R.id.txvDeslikesAnimal7);
        imvCoracaoAnimal7     = findViewById(R.id.imvCoracaoAnimal7);
        clyAnimal8            = findViewById(R.id.clyAnimal8);
        txvNomeAnimal8        = findViewById(R.id.txvNomeAnimal8);
        txvIdadeAnimal8       = findViewById(R.id.txvIdadeAnimal8);
        imvAnimal8            = findViewById(R.id.imvAnimal8);
        imvLikeAnimal8        = findViewById(R.id.imvLikeAnimal8);
        txvLikesAnimal8       = findViewById(R.id.txvLikesAnimal8);
        imvDeslikeAnimal8     = findViewById(R.id.imvDeslikeAnimal8);
        txvDeslikesAnimal8    = findViewById(R.id.txvDeslikesAnimal8);
        imvCoracaoAnimal8     = findViewById(R.id.imvCoracaoAnimal8);
        clyAnimal9            = findViewById(R.id.clyAnimal9);
        txvNomeAnimal9        = findViewById(R.id.txvNomeAnimal9);
        txvIdadeAnimal9       = findViewById(R.id.txvIdadeAnimal9);
        imvAnimal9            = findViewById(R.id.imvAnimal9);
        imvLikeAnimal9        = findViewById(R.id.imvLikeAnimal9);
        txvLikesAnimal9       = findViewById(R.id.txvLikesAnimal9);
        imvDeslikeAnimal9     = findViewById(R.id.imvDeslikeAnimal9);
        txvDeslikesAnimal9    = findViewById(R.id.txvDeslikesAnimal9);
        imvCoracaoAnimal9     = findViewById(R.id.imvCoracaoAnimal9);
        clyAnimal10           = findViewById(R.id.clyAnimal10);
        txvNomeAnimal10       = findViewById(R.id.txvNomeAnimal10);
        txvIdadeAnimal10      = findViewById(R.id.txvIdadeAnimal10);
        imvAnimal10           = findViewById(R.id.imvAnimal10);
        imvLikeAnimal10       = findViewById(R.id.imvLikeAnimal10);
        txvLikesAnimal10      = findViewById(R.id.txvLikesAnimal10);
        imvDeslikeAnimal10    = findViewById(R.id.imvDeslikeAnimal10);
        txvDeslikesAnimal10   = findViewById(R.id.txvDeslikesAnimal10);
        imvCoracaoAnimal10    = findViewById(R.id.imvCoracaoAnimal10);
    }

    private void programarComponentes() {
        botaoMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drlPagina.openDrawer(GravityCompat.START);
            }
        });

        mnuInicial.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                return true;
            }
        });

        mnuPerfil.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Intent perfilUsuario = new Intent(TelaInicial.this, PerfilUsuario.class);
                startActivity(perfilUsuario);
                return true;
            }
        });

        mnuAnimais.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Intent meusAnimais = new Intent(TelaInicial.this, ListaMeusAnimais.class);
                startActivity(meusAnimais);
                return true;
            }
        });

        mnuMensagens.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Toast.makeText(TelaInicial.this, "Funcionalidade ainda não implementada!", Toast.LENGTH_SHORT).show();
                return true;
            }
        });

        mnuOpcoes.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Toast.makeText(TelaInicial.this, "Funcionalidade ainda não implementada!", Toast.LENGTH_SHORT).show();
                return true;
            }
        });

        mnuSair.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                AlertDialog.Builder builder = new AlertDialog.Builder(TelaInicial.this);
                builder.setMessage("Deseja realmente encerrar a sessão?")
                        .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                drlPagina.closeDrawer(GravityCompat.START);
                                FirebaseAuth.getInstance().signOut();
                                Intent enviarFeedback = new Intent(TelaInicial.this, FormLogin.class);
                                enviarFeedback.putExtra("enviarFeedback", 3);
                                startActivity(enviarFeedback);
                                finish();
                            }
                        })
                        .setNegativeButton("Não", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {}
                        })
                        .create()
                        .show();
                return true;
            }
        });

        txvNomeUsuario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent perfilUsuario = new Intent(TelaInicial.this, PerfilUsuario.class);
                startActivity(perfilUsuario);
            }
        });
        imvFotoUsuario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent perfilUsuario = new Intent(TelaInicial.this, PerfilUsuario.class);
                startActivity(perfilUsuario);
            }
        });
    }

    private void recuperarDados() {
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (documentSnapshot != null){
                    txvNomeUsuario.setText(documentSnapshot.getString("nome"));
                    atributoValorUsuario1.setText(documentSnapshot.getString("numAnimais"));
                    atributoValorUsuario2.setText(documentSnapshot.getString("curtidas"));
                    atributoValorUsuario3.setText(documentSnapshot.getString("seguidores"));

                    txvMenuNomeUsuario.setText(documentSnapshot.getString("nome"));

                    carregarFoto();
                }
            }
        });
    }

    private void carregarFoto() {
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (documentSnapshot != null) {
                    String foto = documentSnapshot.getString("foto");
                    if (foto != null && !foto.isEmpty()){
                        imvFotoUsuario.setBackgroundColor(getResources().getColor(R.color.transparent));
                        imvMenuFotoUsuario.setBackgroundColor(getResources().getColor(R.color.transparent));
                        Picasso.get().load(documentSnapshot.getString("foto")).into(imvFotoUsuario);
                        Picasso.get().load(documentSnapshot.getString("foto")).into(imvMenuFotoUsuario);
                    }
                }
            }
        });
    }

    @Override
    public void onBackPressed(){
        if (drlPagina.isDrawerOpen(GravityCompat.START)) {
            drlPagina.closeDrawer(GravityCompat.START);
        } else {
            finishAffinity();
        }
    }
}