package com.example.animoreproject;

import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class AdapterAnimal extends RecyclerView.Adapter<AdapterAnimal.ViewHolder> {
    private List<ItemMeuAnimal> listaAnimal;

    public AdapterAnimal(List<ItemMeuAnimal> listaAnimal) {
        this.listaAnimal = listaAnimal;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_meus_animais, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ItemMeuAnimal meuAnimal = listaAnimal.get(position);

        Picasso.get().load(meuAnimal.getImagem()).into(holder.imvMeuAnimal);
        holder.txvNomeMeuAnimal.setText(meuAnimal.getNome());
        holder.txvIdadeMeuAnimal.setText(meuAnimal.getIdade());
        holder.txvRacaMeuAnimal.setText(meuAnimal.getRaca());
    }

    @Override
    public int getItemCount() {
        return listaAnimal.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView imvMeuAnimal;
        public TextView txvNomeMeuAnimal;
        public TextView txvIdadeMeuAnimal;
        public TextView txvRacaMeuAnimal;

        public ViewHolder(View view) {
            super(view);
            imvMeuAnimal      = view.findViewById(R.id.imvMeuAnimal);
            txvNomeMeuAnimal  = view.findViewById(R.id.txvNomeMeuAnimal);
            txvIdadeMeuAnimal = view.findViewById(R.id.txvIdadeMeuAnimal);
            txvRacaMeuAnimal  = view.findViewById(R.id.txvRacaMeuAnimal);
        }
    }
}
