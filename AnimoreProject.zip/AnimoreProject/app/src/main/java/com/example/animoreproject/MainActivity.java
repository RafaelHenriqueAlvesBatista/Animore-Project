package com.example.animoreproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private int tela = 0;
    private String cargo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseUser usuarioAtual = FirebaseAuth.getInstance().getCurrentUser();

        if (usuarioAtual != null && tela != 0){
            tela = 6;
            onResume();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        // TELA ZERO - DEBUG
        if (tela == 0) {
            setContentView(R.layout.activity_debug);
            Button botao1 = findViewById(R.id.tela1);
            Button botao2 = findViewById(R.id.tela2);
            Button botao3 = findViewById(R.id.tela3);
            Button botao4 = findViewById(R.id.tela4);
            Button botao5 = findViewById(R.id.tela5);
            Button botao6 = findViewById(R.id.tela6);
            Button botao7 = findViewById(R.id.tela7);
            Button botao8 = findViewById(R.id.tela8);
            Button botao9 = findViewById(R.id.tela9);
            Button botao10 = findViewById(R.id.tela10);
            Button botao11 = findViewById(R.id.tela11);
            Button botao12 = findViewById(R.id.tela12);
            Button botao13 = findViewById(R.id.tela13);
            Button botao14 = findViewById(R.id.tela14);
            Button botao15 = findViewById(R.id.tela15);
            Button deslogar = findViewById(R.id.deslogar);

            botao1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tela = 1;
                    onResume();
                }
            });
            botao2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tela = 2;
                    onResume();
                }
            });
            botao3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tela = 3;
                    onResume();
                }
            });
            botao4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tela = 4;
                    onResume();
                }
            });
            botao5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tela = 5;
                    onResume();
                }
            });
            botao6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tela = 6;
                    onResume();
                }
            });
            botao7.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tela = 7;
                    onResume();
                }
            });
            botao8.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tela = 8;
                    onResume();
                }
            });
            botao9.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tela = 9;
                    onResume();
                }
            });
            botao10.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tela = 10;
                    onResume();
                }
            });
            botao11.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tela = 11;
                    onResume();
                }
            });
            botao12.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tela = 12;
                    onResume();
                }
            });
            botao13.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tela = 13;
                    onResume();
                }
            });
            botao14.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tela = 14;
                    onResume();
                }
            });
            botao15.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tela = 15;
                    onResume();
                }
            });
            deslogar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    FirebaseAuth.getInstance().signOut();
                    onResume();
                    Toast.makeText(MainActivity.this, "Usuário deslogado com sucesso!", Toast.LENGTH_SHORT).show();
                }
            });
        }

        // PRIMEIRA TELA - BOAS VINDAS
        if (tela == 1){
            setContentView(R.layout.activity_boas_vindas);
            Button botaoComecar = findViewById(R.id.btnComecar);
            botaoComecar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tela = 3;
                    onResume();
                }
            });
        }

        // SEGUNDA TELA - ESCOLHA DO CARGO
        if (tela == 2){
            setContentView(R.layout.activity_escolha_cargo);

            TextView txvDescricao = findViewById(R.id.txvDescricao);
            Button botaoDoar = findViewById(R.id.btnDoar);
            Button botaoDoarInativo = findViewById(R.id.btnDoarInativo);
            Button botaoAdotar = findViewById(R.id.btnAdotar);
            Button botaoAdotarInativo = findViewById(R.id.btnAdotarInativo);
            Button botaoContinuar1 = findViewById(R.id.btnContinuar1);
            Button botaoContinuar1Ativo = findViewById(R.id.btnContinuar1Ativo);
            Button botaoVoltar = findViewById(R.id.btnVoltar);

            botaoDoar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    executarEscolha();
                    txvDescricao.setText(R.string.text_welcome_2_Donate);
                    cargo = "d";
                }
            });

            botaoAdotar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    executarEscolha();
                    txvDescricao.setText(R.string.text_welcome_2_Adopt);
                    cargo = "a";
                }
            });

            botaoContinuar1Ativo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    tela = 3;
                    Intent telaLogin = new Intent(MainActivity.this, FormLogin.class);
                    telaLogin.putExtra("cargoEscolhido", cargo);
                    startActivity(telaLogin);
                    System.out.println("Cargo escolhido: " + cargo);
                }
            });

            botaoVoltar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onBackPressed();
                }
            });
        }

        // TERCEIRA TELA - LOGIN
        if (tela == 3){
            Intent telaLogin = new Intent(MainActivity.this, FormLogin.class);
            startActivity(telaLogin);
        }

        // QUARTA TELA - REGISTRAR
        if (tela == 4) {
            Intent fazerCadastro = new Intent(MainActivity.this, FormCadastro.class);
            startActivity(fazerCadastro);
        }

        // QUINTA TELA - ESQUECI SENHA
        if (tela == 5) {
            Intent esqueciSenha = new Intent(MainActivity.this, FormEsqueciSenha.class);
            startActivity(esqueciSenha);
        }

        // SEXTA TELA - TELA INICIAL
        if (tela == 6) {
            Intent telaInicial = new Intent(MainActivity.this, TelaInicial.class);
            startActivity(telaInicial);
        }

        // SETIMA TELA - PERFIL DO USUARIO
        if (tela == 7) {
            Intent perfilUsuario = new Intent(MainActivity.this, PerfilUsuario.class);
            startActivity(perfilUsuario);
        }

        // OITAVA TELA - MEUS ANIMAIS
        if (tela == 8) {
            Intent meusAnimais = new Intent(MainActivity.this, ListaMeusAnimais.class);
            startActivity(meusAnimais);
        }

        // NONA TELA - PERFIL DO ANIMAL
        if (tela == 9) {
            Intent perfilAnimal = new Intent(MainActivity.this, PerfilAnimal.class);
            startActivity(perfilAnimal);
        }

        // DECIMA TELA - CADASTRO ANIMAL
        if (tela == 10) {
            Intent cadastroAnimal = new Intent(MainActivity.this, FormCadastroAnimal.class);
            startActivity(cadastroAnimal);
        }

        // DECIMA-PRIMEIRA TELA - CONFIGURACOES APLICATIVO
        if (tela == 11) {
            Intent opcoesApp = new Intent(MainActivity.this, TelaOpcoes.class);
            startActivity(opcoesApp);
        }

        // DECIMA-SEGUNDA TELA - TEMPLATE LAYOUT
        if (tela == 12) {
            setContentView(R.layout.activity_template);
        }

        // DECIMA-TERCEIRA TELA - SPLASH SCREEN
        if (tela == 13) {
            Intent splashScreen = new Intent(MainActivity.this, SplashScreen.class);
            startActivity(splashScreen);
            finish();
        }

        // DECIMA-QUARTA TELA - NAVIGATION VIEW HEADER
        if (tela == 14) {
            setContentView(R.layout.nav_header);
        }

        // DECIMA-QUINTA TELA - CUSTOM SPINNER CHECKBOX LAYOUT
        if (tela == 15) {
            setContentView(R.layout.checkbox_item);
        }
    }

    private void executarEscolha() {
        Button botaoDoar = findViewById(R.id.btnDoar);
        Button botaoDoarInativo = findViewById(R.id.btnDoarInativo);
        Button botaoAdotar = findViewById(R.id.btnAdotar);
        Button botaoAdotarInativo = findViewById(R.id.btnAdotarInativo);
        Button botaoContinuar1 = findViewById(R.id.btnContinuar1);
        Button botaoContinuar1Ativo = findViewById(R.id.btnContinuar1Ativo);

        botaoDoar.setVisibility(View.INVISIBLE);
        botaoDoar.setEnabled(false);
        botaoDoarInativo.setVisibility(View.VISIBLE);
        botaoAdotar.setVisibility(View.INVISIBLE);
        botaoAdotar.setEnabled(false);
        botaoAdotarInativo.setVisibility(View.VISIBLE);
        botaoContinuar1.setVisibility(View.INVISIBLE);
        botaoContinuar1Ativo.setEnabled(true);
        botaoContinuar1Ativo.setVisibility(View.VISIBLE);
    }

    @Override
    public void onBackPressed(){
        if (tela == 2){
            tela = 1;
            onResume();
        }
        else {
            finishAffinity();
        }
    }
}