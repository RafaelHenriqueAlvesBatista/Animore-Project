package com.example.animoreproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.w3c.dom.Text;

import java.util.Objects;

public class TelaProcurar extends AppCompatActivity {

    private TextView txvTituloProcurar;
    private FloatingActionButton fabVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_procurar);

        txvTituloProcurar = findViewById(R.id.txvTituloProcurar);
        fabVoltar = findViewById(R.id.fabVoltar);

        Intent receberTitulo = getIntent();
        System.out.println("RECEBEU A INTENT");
        if (receberTitulo.getIntExtra("tituloProcurar", 0) == 1){
            txvTituloProcurar.setText(R.string.title_searchAnimals);
        } else if (receberTitulo.getIntExtra("tituloProcurar", 0) == 2){
            txvTituloProcurar.setText(R.string.title_searchAccesories);
        }

        fabVoltar.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            onBackPressed();
        }
    });
}

    @Override
    public void onBackPressed() {
        finish();
    }
}