package com.example.animoreproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class PerfilAnimal extends AppCompatActivity {

    // COMPONENTES TOOLBAR
    private ImageButton botaoMenu, botaoCompartilhar;

    // COMPONENTES TELA
    private DrawerLayout drlPagina;
    private View headerView;
    private ScrollView scvTela;
    private FloatingActionButton fabVoltar;

    // COMPONENTES MENU
    private NavigationView nvvMenu;
    private TextView txvMenuNomeUsuario;
    private ImageView imvMenuFotoUsuario;
    private Menu menu;
    private MenuItem mnuInicial;
    private MenuItem mnuPerfil;
    private MenuItem mnuAnimais;
    private MenuItem mnuMensagens;
    private MenuItem mnuOpcoes;
    private MenuItem mnuSair;

    // COMPONENTES ANIMAL
    private ImageView imvFotoAnimal;
    private TextView txvNomeAnimal, txvRacaAnimal, txvIdadeAnimal, txvLocalAnimal;

    // BOTAO ADOTAR ANIMAL
    private LinearLayout btnAdotarAnimal;

    // DESCRICAO ANIMAL
    private TextView txvDescricao, txvLerMais;

    // COMPONENTES DONO ANIMAL
    private LinearLayout llyLigarDono, llyMensagemDono;

    // VACINAS ANIMAL
    private LinearLayout llyVacinaAnimal1, llyVacinaAnimal2, llyVacinaAnimal3, llyVacinaAnimal4;
    private TextView txvVacinaAnimalVazio;

    // FOTOS ANIMAL
    private ImageView imvFotoAnimal1, imvFotoAnimal2, imvFotoAnimal3, imvFotoAnimal4, imvFotoAnimal5;

    // VARIAVEIS DA ACTIVITY
    private boolean textoRevelado;
    private int limiteCaracteres;
    private String descricaoCompleta, descricaoCurta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil_animal);
        instanciarComponentes();
        programarComponentes();
        limitarDescricaoGrande();
        receberIntent();
    }

    private void instanciarComponentes() {
        botaoMenu             = findViewById(R.id.botaoMenu);
        botaoCompartilhar     = findViewById(R.id.botaoCompartilhar);

        drlPagina             = findViewById(R.id.drlPagina);

        nvvMenu               = findViewById(R.id.nvvMenu);
        headerView            = nvvMenu.getHeaderView(0);

        txvMenuNomeUsuario    = headerView.findViewById(R.id.txvMenuNomeUsuario);
        imvMenuFotoUsuario    = headerView.findViewById(R.id.imvMenuFotoUsuario);
        menu                  = nvvMenu.getMenu();
        mnuInicial            = menu.findItem(R.id.menu_paginaInicial);
        mnuPerfil             = menu.findItem(R.id.menu_perfil);
        mnuAnimais            = menu.findItem(R.id.menu_meusAnimais);
        mnuMensagens          = menu.findItem(R.id.menu_mensagens);
        mnuOpcoes             = menu.findItem(R.id.menu_opcoes);
        mnuSair               = menu.findItem(R.id.menu_sair);

        fabVoltar             = findViewById(R.id.fabVoltar);

        scvTela               = findViewById(R.id.scvTela);

        imvFotoAnimal         = findViewById(R.id.imvFotoAnimal);
        txvNomeAnimal         = findViewById(R.id.txvNomeAnimal);
        txvRacaAnimal         = findViewById(R.id.txvRacaAnimal);
        txvIdadeAnimal        = findViewById(R.id.txvIdadeAnimal);
        txvLocalAnimal        = findViewById(R.id.txvLocalAnimal);

        btnAdotarAnimal       = findViewById(R.id.btnAdotarAnimal);

        txvDescricao          = findViewById(R.id.txvDescricao);
        txvLerMais            = findViewById(R.id.txvLerMais);

        llyLigarDono          = findViewById(R.id.llyLigarDono);
        llyMensagemDono       = findViewById(R.id.llyMensagemDono);

        llyVacinaAnimal1      = findViewById(R.id.llyVacinaAnimal1);
        llyVacinaAnimal2      = findViewById(R.id.llyVacinaAnimal2);
        llyVacinaAnimal3      = findViewById(R.id.llyVacinaAnimal3);
        llyVacinaAnimal4      = findViewById(R.id.llyVacinaAnimal4);
        txvVacinaAnimalVazio  = findViewById(R.id.txvVacinaAnimalVazio);

        imvFotoAnimal1        = findViewById(R.id.imvFotoAnimal1);
        imvFotoAnimal2        = findViewById(R.id.imvFotoAnimal2);
        imvFotoAnimal3        = findViewById(R.id.imvFotoAnimal3);
        imvFotoAnimal4        = findViewById(R.id.imvFotoAnimal4);
        imvFotoAnimal5        = findViewById(R.id.imvFotoAnimal5);

        textoRevelado         = false;
        limiteCaracteres      = 200;
        descricaoCompleta     = getResources().getString(R.string.test_placeholderParaph);
        descricaoCurta        = descricaoCompleta.substring(0, limiteCaracteres);
    }

    private void programarComponentes() {
        botaoMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drlPagina.openDrawer(GravityCompat.START);
            }
        });

        mnuInicial.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Intent telaInicial = new Intent(PerfilAnimal.this, TelaInicial.class);
                startActivity(telaInicial);
                return true;
            }
        });

        mnuPerfil.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Intent perfilUsuario = new Intent(PerfilAnimal.this, PerfilUsuario.class);
                startActivity(perfilUsuario);
                return true;
            }
        });

        mnuAnimais.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Intent meusAnimais = new Intent(PerfilAnimal.this, ListaMeusAnimais.class);
                startActivity(meusAnimais);
                return true;
            }
        });

        mnuMensagens.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Toast.makeText(PerfilAnimal.this, "Funcionalidade ainda não implementada!", Toast.LENGTH_SHORT).show();
                return true;
            }
        });

        mnuOpcoes.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                drlPagina.closeDrawer(GravityCompat.START);
                Intent telaOpcoes = new Intent(PerfilAnimal.this, TelaOpcoes.class);
                startActivity(telaOpcoes);
                return true;
            }
        });

        mnuSair.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(@NonNull MenuItem menuItem) {
                AlertDialog.Builder builder = new AlertDialog.Builder(PerfilAnimal.this);
                builder.setMessage("Deseja realmente encerrar a sessão?")
                        .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                drlPagina.closeDrawer(GravityCompat.START);
                                FirebaseAuth.getInstance().signOut();
                                Intent enviarFeedback = new Intent(PerfilAnimal.this, FormLogin.class);
                                enviarFeedback.putExtra("enviarFeedback", 3);
                                startActivity(enviarFeedback);
                                finish();
                            }
                        })
                        .setNegativeButton("Não", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {}
                        })
                        .create()
                        .show();
                return true;
            }
        });

        fabVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        txvLerMais.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!textoRevelado) {
                    txvDescricao.setText(descricaoCompleta);
                    txvLerMais.setText(getResources().getString(R.string.btn_readLess));
                    textoRevelado = true;
                } else {
                    txvDescricao.setText(descricaoCurta + "...");
                    txvLerMais.setText(getResources().getString(R.string.btn_readMore));
                    textoRevelado = false;
                }
            }
        });

        btnAdotarAnimal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                avisoAdotar();
            }
        });
    }

    private void limitarDescricaoGrande() {
        if (descricaoCompleta.length() > limiteCaracteres) {
            txvDescricao.setText(descricaoCurta + "...");
            txvLerMais.setVisibility(View.VISIBLE);
        }
    }

    private void receberIntent() {
        Intent receberIntent = getIntent();
        System.out.println(receberIntent.getStringExtra("IDanimal"));
        // TODO
    }

    private void avisoAdotar() {
        AlertDialog.Builder builder = new AlertDialog.Builder(PerfilAnimal.this);
        builder.setIcon(R.drawable.ic_aviso);
        builder.setTitle("Aviso");
        builder.setMessage("\nAo realizar essa ação, será notificada ao dono do animal sobre a solicitação de adoção, e você entrará em uma tela de conversa com o mesmo.\nProsseguir com a solicitação?")
                .setPositiveButton("Sim", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //TODO
                    }
                })
                .setNegativeButton("Não", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {}
                })
                .create()
                .show();
    }

    @Override
    public void onBackPressed() {
        if (drlPagina.isDrawerOpen(GravityCompat.START)) {
            drlPagina.closeDrawer(GravityCompat.START);
        } else {
            finish();
        }
    }
}