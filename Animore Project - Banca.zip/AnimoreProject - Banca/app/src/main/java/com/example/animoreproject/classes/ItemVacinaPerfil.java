package com.example.animoreproject.classes;

public class ItemVacinaPerfil {
    private String nome;

    public ItemVacinaPerfil(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }
}
